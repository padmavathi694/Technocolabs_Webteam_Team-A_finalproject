import React from 'react';
 
  import './App.css';
  import Organic from './pages/Organic';
  import Product1 from './pages/Product1';
  import Product2 from './pages/Product2';
  import Contact from './pages/Contact';
  import Shop from './pages/Shop';
  import Pantry from './pages/Pantry';
  import Fresh from './pages/Fresh';
  import Almonds from './pages/Almonds';
  import Mangoes from './pages/Mangoes';
  import Tadka from './pages/Tadka';
  import Strawberry from './pages/Strawberry';
  import Pomogranade from './pages/Pomogranade';
  import Cosmetic from './pages/Cosmetic';
  import Medical from './pages/Medical';
  import Account from './pages/Account';
import Customer1 from './pages/Customer1';
import Customer2 from './pages/Customer2';
import Essentials from './pages/Essentials';
import Medicalshop from './pages/Medicalshop';
import Fashion from './pages/Fashion';
import Snacks from './pages/Snacks';
import Singleoticon from './pages/Singleoticon';
import Singlehempoil from './pages/Singlehempoil';
import Furniture from './pages/Furniture';
import Login from './pages/Login';
import Appliences from './pages/Appliences';
import Lights from './pages/Lights';
import Blog1 from './pages/Blog1';
import Blog2 from './pages/Blog2';
import Checkout from './pages/Checkout';
import Furnitureshop from './pages/Furnitureshop';
import Singleproductlightdecor1 from './pages/Singleproductlightdecor1';
import Singleproductlightdecor2 from './pages/Singleproductlightdecor2';
import SingleproductArmlessCushionedChair from './pages/SingleproductArmlessCushionedChair';
import SingleproductCushionedChair from './pages/SingleproductCushionedChair';
import SingleproductHeavyCushionedChairXl from './pages/SingleproductHeavyCushionedChairXl';
import SingleproductBarChair from './pages/SingleproductBarChair';
import SingleproductSingleLegStool from './pages/SingleproductSingleLegStool';
import SingleproductCushionedChair2 from './pages/SingleproductCushionedChair2';
import SingleproductArmlessMetalChair from './pages/SingleproductArmlessMetalChair';
import SingleproductBarStool from './pages/SingleproductBarStool';
import OfficeFurniture from './pages/OfficeFurniture';
import OutdoorFurniture from './pages/OutdoorFurniture';
import IndoorLighting from './pages/IndoorLighting';
import WallClocks from './pages/WallClocks';

import Shopcos from './pages/Shopcos';
import Snackshop from './pages/Snackshop';

import Wishlist from './pages/Wishlist';
import Cart from './pages/Cart';
import Fashionshop from './pages/Fashionshop';
import Digital from './pages/Digital';
import About from './pages/About';
import Compare from './pages/Compare';
import DigitalShop from './pages/DigitalShop';
import PixelPhone from './pages/PixelPhone';
import AlphonsoMangoes from './pages/AlphonsoMangoes';
import ArmedChair from './pages/ArmedChair';
import Cctv from './pages/Cctv';
import GoPro from './pages/GoPro';

import Pinkclaysoap from './pages/Pinkclaysoap';
import Minimakeup from './pages/Minimakeup';
import Concealor from './pages/Concealor';
import Lipgloss from './pages/Lipgloss';
 
  import Header from './pages/Header';
  import Footer from './pages/Footer';
  import {BrowserRouter as Router,Route,Switch} from 'react-router-dom';

 
  function App()
  {
    return (
      <div>
        <Router>
     <Header/>

      <Switch>
   <Route exact path='/' component={Organic} />
  <Route exact path='/Product1' component={Product1} />
    <Route exact  path='/Product2' component={Product2} />
      <Route exact path='/Contact' component={Contact} />
        <Route exact path='/Shop' component={Shop} />
          <Route exact path='/Pantry' component={Pantry} />
            <Route exact path='/Fresh' component={Fresh} />
            <Route exact path='/Almonds' component={Almonds} />
            <Route exact path='/Mangoes' component={Mangoes} />
            <Route exact path='/Strawberry' component={Strawberry} />
            <Route exact path='/Pomogranade' component={Pomogranade} />
            <Route exact path='/Tadka' component={Tadka} />
            
            <Route path='/my-account' component={Account} />
            <Route path='/Medical' component={Medical} />
          <Route path='/blog-single-left-sidebar' component={Customer1} />
          <Route path='/blog-single-right-sidebar' component={Customer2} />
          <Route path='/single-product-thrmometer' component={Essentials} />
          <Route path='/shop-right-sidebar' component={Medicalshop} />
          <Route path='/single-product-concealor' component={Fashion} />
          <Route path='/single-product-punjabi tadka' component={Snacks} />
          <Route path='/single-product-oticon' component={Singleoticon} />
          <Route path='/single-product-hemp-oil' component={Singlehempoil} />
          <Route path='/Furniture' component={Furniture}/>
          <Route path='/Login' component={Login}/>
          <Route path='/Applinces' component={Appliences}/>
          <Route path='/Lights' component={Lights}/>
          <Route path='/Blog1' component={Blog1}/>
          <Route path='/Blog2' component={Blog2}/>
          <Route path='/Checkout' component={Checkout}/>
          <Route path='/Furnitureshop' component={Furnitureshop}/>
          <Route path='/Singleproductlightdecor1' component={Singleproductlightdecor1}/>
          <Route path='/Singleproductlightdecor2' component={Singleproductlightdecor2}/>
          <Route path='/SingleproductArmlessCushionedChair' component={SingleproductArmlessCushionedChair}/>
          <Route path='/SingleproductCushionedChair' component={SingleproductCushionedChair}/>
          <Route path='/SingleproductHeavyCushionedChairXl'component={SingleproductHeavyCushionedChairXl}/>
          <Route path='/SingleproductBarChair' component={SingleproductBarChair}/>
          <Route path='/SingleproductSingleLegStool' component={SingleproductSingleLegStool}/>
          <Route path='/SingleproductCushionedChair2' component={SingleproductCushionedChair2}/>
          <Route path='/SingleproductArmlessMetalChair' component={SingleproductArmlessMetalChair}/>
          <Route path='/SingleproductBarStool' component={SingleproductBarStool}/>
          <Route path='/OfficeFurniture' component={OfficeFurniture}/>
          <Route path='/OutdoorFurniture' component={OutdoorFurniture}/>
          <Route path='/IndoorLighting' component={IndoorLighting}/>
          <Route path='/WallClocks' component={WallClocks}/>
          
          <Route path='/Shopcos' component={Shopcos}/>
          <Route path='/shop-3-column' component={Fashionshop} />
          <Route path='/shop-4-column' component={Snackshop} />
          <Route path='/Cart' component={Cart} />
          <Route path='/Wishlist' component={Wishlist} />
          
          <Route exact path='/Digital' component={Digital} />
          <Route exact path='/About' component={About} />
          <Route exact path='/Compare' component={Compare} />
          <Route exact path='/DigitalShop' component={DigitalShop} />
          <Route exact path='/PixelPhone' component={PixelPhone} />
          <Route exact path='/AlphonsoMangoes' component={AlphonsoMangoes} />
          <Route exact path='/ArmedChair' component={ArmedChair} />
          <Route exact path='/Cctv' component={Cctv} />
          <Route exact path='/GoPro' component={GoPro} />
          <Route exact path='/Cosmetics' component={Cosmetic} />
   <Route exact path='/Pinkclaysoap' component={Pinkclaysoap} />
   <Route exact path='/Minimakeup' component={Minimakeup} />
   <Route exact path='/Concealor' component={Concealor} />
   <Route exact path='/Lipgloss' component={Lipgloss} />
   
   

  </Switch>
         
         <Footer/>
          </Router>
          </div>
    );
    
    
  }
export default App;


