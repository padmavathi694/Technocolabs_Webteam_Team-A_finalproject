//import { react } from '@babel/types';
import { assertExpressionStatement } from "@babel/types";
import React from "react";
import axios from "axios";
import {Link} from 'react-router-dom';




class Login extends React.Component{
  constructor(){
    super()
    this.state = {
      userName:'',
      password:'',
      email:''
    }
    this.changeUserName = this.changeUserName.bind(this)
    this.changePassword = this.changePassword.bind(this)
    this.changeEmail = this.changeEmail.bind(this)
    this.onSubmit = this.onSubmit.bind(this)
  }

  changeUserName(event){
    this.setState({
      userName:event.target.value
    })

  }

  changePassword(event){
    this.setState({
      password:event.target.value
    })

  }

  changeEmail(event){
    this.setState({
      email:event.target.value
    })

  }
onSubmit(event){
  event.preventDefault()

  const registered = {
    userName:this.state.userName,
    password:this.state.password,
    email:this.state.email
  }

  axios.post('http://localhost:4000/app/signup', registered)
  .then(response  => console.log(response.data))

  this.setState({
    userName:'',
    password:'',
    email:''
  })
}


    render(){
        return(
           <div>
  <div>
  {/* Breadcrumb Area start */}
  <section className="breadcrumb-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="breadcrumb-content">
            <h1 className="breadcrumb-hrading">Login / Register Page</h1>
            <ul className="breadcrumb-links">
              <li><a href="index.html">Home</a></li>
              <li>Login / Register</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Area End */}
  {/* login area start */}
  <div className="login-register-area mb-60px mt-53px">
    <div className="container">
      <div className="row">
        <div className="col-lg-7 col-md-12 ml-auto mr-auto">
          <div className="login-register-wrapper">
            <div className="login-register-tab-list nav">
              <a className="active" data-toggle="tab" href="#lg1">
                <h4>login</h4>
              </a>
              <a data-toggle="tab" href="#lg2">
                <h4>register</h4>
              </a>
            </div>
            <div className="tab-content">
              <div id="lg1" className="tab-pane active">
                <div className="login-form-container">
                  <div className="login-register-form">
                    <form action="https://htmldemo.hasthemes.com/ecolife-preview/ecolife/assets/php/mail.php" method="post">
                      <input type="text" name="user-name" placeholder="Username" />
                      <input type="password" name="user-password" placeholder="Password" />
                      <div className="button-box">
                        <div className="login-toggle-btn">
                          <input type="checkbox" />
                          <a className="flote-none" href="javascript:void(0)">Remember me</a>
                          <a href="#">Forgot Password?</a>
                        </div>
                        <Link to="/Organic"><button type="submit"><span>Login</span></button></Link>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
              <div id="lg2" className="tab-pane">
                <div className="login-form-container">
                  <div className="login-register-form">
                    <form onSubmit={this.onSubmit} action="https://htmldemo.hasthemes.com/ecolife-preview/ecolife/assets/php/mail.php" method="post">

                      <input type="text" name="user-name" placeholder="Username"
                       onChange={this.changeUserName} 
                       value={this.state.userName}
                       className='form-control form-group' />

                      <input type="password" name="user-password" placeholder="Password" 
                       onChange={this.changePassword}
                       value={this.state.password}
                       className='form-control form-group'/>

                      <input name="user-email" placeholder="Email" type="email"
                       onChange={this.changeEmail} 
                       value={this.state.email}
                       className='form-control form-group'/>

                      <div className="button-box">
                        <button type="submit" className='btn btn-danger btn-block'><span>Register</span></button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* login area end */}
</div>

           </div>
        );
    }
}
export default Login;