import React from 'react';
import { Link } from 'react-router-dom';

class Digital extends React.Component {

    render() {
        return (
            <div>
                <div>
                    {/* Slider Arae Start */}
                    <div className="slider-area">
                        <div className="slider-active-3 owl-carousel slider-hm8 owl-dot-style">
                            {/* Slider Single Item Start */}
                            <div className="slider-height-9 d-flex align-items-start justify-content-start bg-img" style={{ backgroundImage: 'url(assets/images/slider-image/sample-16.jpg)' }}>
                                <div className="container">
                                    <div className="slider-content-5 slider-animated-1 text-left">
                                        <span className="animated">SOUNLINK SPEAKERS</span>
                                        <h1 className="animated">
                                            <strong> WIN Nedmi PULSE </strong> <br />
                                            Bluetooth Speakers
                                        </h1>
                                        <p className="animated">Big Sound. Portable Size.</p>
                                        <Link to="/DigitalShop" className="shop-btn animated">SHOP NOW</Link>
                                    </div>
                                </div>
                            </div>
                            {/* Slider Single Item End */}
                            {/* Slider Single Item Start */}
                            <div className="slider-height-9 d-flex align-items-start justify-content-start bg-img" style={{ backgroundImage: 'url(assets/images/slider-image/sample-17.jpg)' }}>
                                <div className="container">
                                    <div className="slider-content-5 slider-animated-1 text-left">
                                        <span className="animated">NEW FROM MANASONIC</span>
                                        <h1 className="animated">
                                            <strong>KUMIX EC-45</strong> <br />
                                            Camera Seminar
                                        </h1>
                                        <p className="animated">Super Smooth 4k / Manasonic Sensor</p>
                                        <Link to="/DigitalShop" className="shop-btn animated">SHOP NOW</Link>
                                    </div>
                                </div>
                            </div>
                            {/* Slider Single Item End */}
                        </div>
                    </div>
                    {/* Slider Arae End */}
                    {/* Banner Area Start */}
                    <div className="banner-3-area">
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 mb-res-xs-30 mb-res-sm-30">
                                    <div className="banner-wrapper">
                                        <Link to="/DigitalShop"><img src="assets/images/banner-image/23.jpg" alt /></Link>
                                    </div>
                                </div>
                                <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div className="banner-wrapper mb-30px">
                                        <Link to="/DigitalShop"><img src="assets/images/banner-image/24.jpg" alt /></Link>
                                    </div>
                                    <div className="banner-wrapper">
                                        <Link to="/DigitalShop"><img src="assets/images/banner-image/25.jpg" alt /></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* Banner Area End */}
                    {/* Static Area Start */}
                    <section className="static-area">
                        <div className="container">
                            <div className="static-area-wrap">
                                <div className="row">
                                    {/* Static Single Item Start */}
                                    <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
                                        <div className="single-static pb-res-md-0 pb-res-sm-0 pb-res-xs-0">
                                            <img src="assets/images/icons/static-icons-1.png" alt className="img-responsive" />
                                            <div className="single-static-meta">
                                                <h4>Free Shipping</h4>
                                                <p>On all orders over $75.00</p>
                                            </div>
                                        </div>
                                    </div>
                                    {/* Static Single Item End */}
                                    {/* Static Single Item Start */}
                                    <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
                                        <div className="single-static pb-res-md-0 pb-res-sm-0 pb-res-xs-0 pt-res-xs-20">
                                            <img src="assets/images/icons/static-icons-2.png" alt className="img-responsive" />
                                            <div className="single-static-meta">
                                                <h4>Free Returns</h4>
                                                <p>Returns are free within 9 days</p>
                                            </div>
                                        </div>
                                    </div>
                                    {/* Static Single Item End */}
                                    {/* Static Single Item Start */}
                                    <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
                                        <div className="single-static pt-res-md-30 pb-res-sm-30 pb-res-xs-0 pt-res-xs-20">
                                            <img src="assets/images/icons/static-icons-3.png" alt className="img-responsive" />
                                            <div className="single-static-meta">
                                                <h4>100% Payment Secure</h4>
                                                <p>Your payment are safe with us.</p>
                                            </div>
                                        </div>
                                    </div>
                                    {/* Static Single Item End */}
                                    {/* Static Single Item Start */}
                                    <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
                                        <div className="single-static pt-res-md-30 pb-res-sm-30 pt-res-xs-20">
                                            <img src="assets/images/icons/static-icons-4.png" alt className="img-responsive" />
                                            <div className="single-static-meta">
                                                <h4>Support 24/7</h4>
                                                <p>Contact us 24 hours a day</p>
                                            </div>
                                        </div>
                                    </div>
                                    {/* Static Single Item End */}
                                </div>
                            </div>
                        </div>
                    </section>
                    {/* Static Area End */}
                    {/* Best Sells Area Start */}
                    <section className="best-sells-area">
                        <div className="container">
                            <div className="row">
                                <div className="col-md-12">
                                    {/* Section Title Start */}
                                    <div className="section-title">
                                        <h2>Best Sellers</h2>
                                        <p>CHECK OUT OUR BEST SELLERS</p>
                                    </div>
                                    {/* Section Title Start */}
                                </div>
                            </div>
                            {/* Best Sell Slider Carousel Start */}
                            <div className="best-sell-slider owl-carousel owl-nav-style">
                                {/* Single Item */}
                                <article className="list-product">
                                    <div className="img-block">
                                        <Link to="/DigitalShop" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/1.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/1.jpg" alt />
                                        </Link>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                    <div className="product-decs">
                                        <a className="inner-link" Link to="/DigitalShop"> <span>ELECTRONICS</span></a>
                                        <h2><Link to="/DigitalShop" className="product-link">Lights</Link></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price">€18.90</li>
                                                <li className="current-price">€34.21</li>
                                                <li className="discount-price">-5%</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="add-to-link">
                                        <ul>
                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                            <li>
                                                <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                            </li>
                                            <li>
                                                <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </article>
                                {/* Single Item */}
                                <article className="list-product">
                                    <div className="img-block">
                                        <Link to="/DigitalShop" className="thumbnail">
                                        <img className="first-img" src="assets/images/product-image/electronic/2.jpg" alt />
                                        <img className="second-img" src="assets/images/product-image/electronic/2.jpg" alt />
                                        </Link>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                    <div className="product-decs">
                                        <a className="inner-link" Link to="/DigitalShop"><span>ELECTRONICS</span></a>
                                        <h2><Link to="/DigitalShop" className="product-link">SMART WATCHES</Link></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price">€18.90</li>
                                                <li className="current-price">€15.12</li>
                                                <li className="discount-price">-20%</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="add-to-link">
                                        <ul>
                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                            <li>
                                                <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                            </li>
                                            <li>
                                                <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </article>
                                {/* Single Item */}
                                <article className="list-product">
                                    <div className="img-block">
                                        <Link to="/Cctv" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/3.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/4.jpg" alt />
                                        </Link>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                    <div className="product-decs">
                                        <a className="inner-link" Link to="/Cctv"><span>ELECTRONICS</span></a>
                                        <h2><Link to="/Cctv" className="product-link">CCTV</Link></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price not-cut">€18.90</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="add-to-link">
                                        <ul>
                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                            <li>
                                                <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                            </li>
                                            <li>
                                                 <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </article>
                                {/* Single Item */}
                                <article className="list-product">
                                    <div className="img-block">
                                        <Link to="/DigitalShop" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/5.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/5.jpg" alt />
                                        </Link>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                    <div className="product-decs">
                                        <a className="inner-link" Link to="/DigitalShop"><span>ELECTRONICS</span></a>
                                        <h2><Link to="/DigitalShop" className="product-link">headphones</Link></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price not-cut">€18.90</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="add-to-link">
                                        <ul>
                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                            <li>
                                               <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                            </li>
                                            <li>
                                               <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </article>
                                {/* Single Item */}
                                <article className="list-product">
                                    <div className="img-block">
                                        <Link to="/DigitalShop" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/7.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/8.jpg" alt />
                                        </Link>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                    <div className="product-decs">
                                        <a className="inner-link" Link to="/DigitalShop"><span>MOBILE</span></a>
                                        <h2><Link to="/DigitalShop" className="product-link">SAMSUNG S1</Link></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price not-cut">€18.90</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="add-to-link">
                                        <ul>
                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                            <li>
                                            <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                            </li>
                                            <li>
                                            <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </article>
                                {/* Single Item */}
                                <article className="list-product">
                                    <div className="img-block">
                                        <Link to="/GoPro" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/9.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/10.jpg" alt />
                                        </Link>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                    <div className="product-decs">
                                        <a className="inner-link" Link to="/GoPro"><span>ELECTRONICS</span></a>
                                        <h2><Link to="/GoPro" className="product-link">CAMERA</Link></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price not-cut">€18.90</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="add-to-link">
                                        <ul>
                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                            <li>
                                            <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                            </li>
                                            <li>
                                            <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </article>
                                {/* Single Item */}
                                <article className="list-product">
                                    <div className="img-block">
                                        <Link to="/DigitalShop" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/11.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/11.jpg" alt />
                                        </Link>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                    <div className="product-decs">
                                        <a className="inner-link" Link to="/DigitalShop"><span>STUDIO DESIGN</span></a>
                                        <h2><Link to="/DigitalShop" className="product-link">Water and Wind Resistant Ins..</Link></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price not-cut">€18.90</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="add-to-link">
                                        <ul>
                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                            <li>
                                            <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                            </li>
                                            <li>
                                            <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </article>
                                {/* Single Item */}
                            </div>
                            {/* Single item */}
                        </div>
                    </section></div>
                {/* Category Area End  */}
                {/* Hot deal area Start */}
                <section className="hot-deal-area">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                {/* Section Title */}
                                <div className="section-title">
                                    <h2>Hot Deals</h2>
                                    <p>Add hot products to weekly line up</p>
                                </div>
                                {/* Section Title */}
                            </div>
                        </div>
                        {/* Hot Deal Slider 2 Start */}
                        <div className="hot-deal-2 owl-carousel owl-nav-style">
                            {/* Single Item */}
                            <article className="list-product">
                                <div className="hot-item-inner">
                                    <div className="img-block">
                                        <Link to="/DigitalShop" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/8.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/8.jpg" alt />
                                        </Link>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                </div>
                                <div className="product-wrapper">
                                    <div className="product-decs">
                                        <a className="inner-link" Link to="/DigitalShop"><span>STUDIO DESIGN</span></a>
                                        <h2><Link to="/DigitalShop" className="product-link">top smart phone</Link></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price">€18.90</li>
                                                <li className="current-price">€34.21</li>
                                                <li className="discount-price">-5%</li>
                                            </ul>
                                        </div>
                                        <div className="add-to-link">
                                            <ul>
                                                <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                <li>
                                                <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                </li>
                                                <li>
                                                <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="in-stock">Availability: <span>300 In Stock</span></div>
                                    <div className="clockdiv">
                                        <div className="title_countdown">Hurry Up! Offers ends in:</div>
                                        <div data-countdown="2021/03/01" />
                                    </div>
                                </div>
                            </article>
                            {/* Single Item */}
                            <article className="list-product">
                                <div className="hot-item-inner">
                                    <div className="img-block">
                                        <Link to="/DigitalShop" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/10.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/4.jpg" alt />
                                        </Link>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                </div>
                                <div className="product-wrapper">
                                    <div className="product-decs">
                                        <a className="inner-link" Link to="/DigitalShop"><span>STUDIO DESIGN</span></a>
                                        <h2><Link to="/DigitalShop" className="product-link">brix top camera</Link></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price">€18.90</li>
                                                <li className="current-price">€34.21</li>
                                                <li className="discount-price">-5%</li>
                                            </ul>
                                        </div>
                                        <div className="add-to-link">
                                            <ul>
                                                <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                <li>
                                                <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                </li>
                                                <li>
                                                <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="in-stock">Availability: <span>300 In Stock</span></div>
                                    <div className="clockdiv">
                                        <div className="title_countdown">Hurry Up! Offers ends in:</div>
                                        <div data-countdown="2021/03/01" />
                                    </div>
                                </div>
                            </article>
                            {/* Single Item */}
                            <article className="list-product">
                                <div className="hot-item-inner">
                                    <div className="img-block">
                                        <a href="single-product.html" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/1.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/1.jpg" alt />
                                        </a>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                </div>
                                <div className="product-wrapper">
                                    <div className="product-decs">
                                        <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                        <h2><a href="single-product.html" className="product-link">New Balance Fresh Foam Kaymin</a></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price">€18.90</li>
                                                <li className="current-price">€34.21</li>
                                                <li className="discount-price">-5%</li>
                                            </ul>
                                        </div>
                                        <div className="add-to-link">
                                            <ul>
                                                <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                <li>
                                                <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                </li>
                                                <li>
                                                <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="in-stock">Availability: <span>299 In Stock</span></div>
                                    <div className="clockdiv">
                                        <div className="title_countdown">Hurry Up! Offers ends in:</div>
                                        <div data-countdown="2021/03/01" />
                                    </div>
                                </div>
                            </article>
                            {/* Single Item */}
                            <article className="list-product">
                                <div className="hot-item-inner">
                                    <div className="img-block">
                                        <a href="shop-left-sidebar.html" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/7.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/8.jpg" alt />
                                        </a>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                </div>
                                <div className="product-wrapper">
                                    <div className="product-decs">
                                        <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                        <h2><a href="shop-left-sidebar.html" className="product-link">Madden by Steve Madden Cale 6</a></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price">€18.90</li>
                                                <li className="current-price">€34.21</li>
                                                <li className="discount-price">-5%</li>
                                            </ul>
                                        </div>
                                        <div className="add-to-link">
                                            <ul>
                                                <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                <li>
                                                <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                </li>
                                                <li>
                                                <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="in-stock">Availability: <span>299 In Stock</span></div>
                                    <div className="clockdiv">
                                        <div className="title_countdown">Hurry Up! Offers ends in:</div>
                                        <div data-countdown="2021/03/01" />
                                    </div>
                                </div>
                            </article>
                            {/* Single Item */}
                            <article className="list-product">
                                <div className="hot-item-inner">
                                    <div className="img-block">
                                        <a href="shop-left-sidebar.html" className="thumbnail">
                                            <img className="first-img" src="assets/images/product-image/electronic/10.jpg" alt />
                                            <img className="second-img" src="assets/images/product-image/electronic/11.jpg" alt />
                                        </a>
                                        <div className="quick-view">
                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                <i className="ion-ios-search-strong" />
                                            </a>
                                        </div>
                                    </div>
                                    <ul className="product-flag">
                                        <li className="new">New</li>
                                    </ul>
                                </div>
                                <div className="product-wrapper">
                                    <div className="product-decs">
                                        <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                                        <h2><a href="shop-left-sidebar.html" className="product-link">Originals Kaval Windbreaker Wint...</a></h2>
                                        <div className="rating-product">
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                            <i className="ion-android-star" />
                                        </div>
                                        <div className="pricing-meta">
                                            <ul>
                                                <li className="old-price">€18.90</li>
                                                <li className="current-price">€34.21</li>
                                                <li className="discount-price">-5%</li>
                                            </ul>
                                        </div>
                                        <div className="add-to-link">
                                            <ul>
                                                <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                <li>
                                                <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                </li>
                                                <li>
                                                <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="in-stock">Availability: <span>300 In Stock</span></div>
                                    <div className="clockdiv">
                                        <div className="title_countdown">Hurry Up! Offers ends in:</div>
                                        <div data-countdown="2021/03/01" />
                                    </div>
                                </div>
                            </article>
                        </div>
                        {/* Hot Deal Slider 2 Start */}
                    </div>
                </section>
                {/* Hot Deal Area End */}
                {/* Category Tab Area Start */}
                {/* Category Tab Area Start */}
                <section className="category-tab-area sub-category-owl-nav mt-30">
                    <div className="container">
                        <div className="section-title">
                            <h2>Portable Audio &amp; Video</h2>
                            {/* Nav tabs */}
                            <ul className="nav nav-tabs sub-category mb-30px">
                                <li className="nav-item">
                                    <a className="nav-link active" data-toggle="tab" href="#feature-2">Headphones</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" data-toggle="tab" href="#onsale-2">Speakers</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" data-toggle="tab" href="#bestseller-2">MP3 Players</a>
                                </li>
                                {/*<li class="nav-item">
                          <a class="nav-link" data-toggle="tab" href="#bestseller-3">Microphones</a>
                      </li>!*/}
                            </ul>
                        </div>
                        {/* Tab panes */}
                        <div className="tab-content">
                            {/* 1st tab start */}
                            <div id="feature-2" className="tab-pane active">
                                <div className="row">
                                    <div className="col-xs-12 col-sm-12 col-md-5 col-lg-5 col-xl-4">
                                        <div className="banner-wrapper">
                                            <Link to="/DigitalShop"><img src="assets/images/banner-image/27.jpg" alt /></Link>
                                        </div>
                                    </div>
                                    {/* New Arrivals Area Start */}
                                    <div className="col-xs-12 col-sm-12 col-md-7 col-lg-7 col-xl-8 mt-res-sm-90 mt-res-sm-60 mt-res-sm-60">
                                        {/* New Product Slider Start */}
                                        <div className="new-product-slider owl-carousel owl-nav-style">
                                            {/* Product Single Item */}
                                            <div className="product-inner-item">
                                                <article className="list-product mb-30px">
                                                    <div className="img-block">
                                                        <Link to="/Cctv" className="thumbnail">
                                                            <img className="first-img" src="assets/images/product-image/electronic/3.jpg" alt />
                                                        </Link>
                                                        <div className="quick-view">
                                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                                <i className="ion-ios-search-strong" />
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <ul className="product-flag">
                                                        <li className="new">New</li>
                                                    </ul>
                                                    <div className="product-decs">
                                                        <a className="inner-link" Link to="/Cctv"><span>ELECTRONICS</span></a>
                                                        <h2><Link to="/Cctv" className="product-link">CCTV CAMERA</Link></h2>
                                                        <div className="rating-product">
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                        </div>
                                                        <div className="pricing-meta">
                                                            <ul>
                                                                <li className="old-price">€23.90</li>
                                                                <li className="current-price">€21.51</li>
                                                                <li className="discount-price">-10%</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div className="add-to-link">
                                                        <ul>
                                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                            <li>
                                                            <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                            </li>
                                                            <li>
                                                            <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </article>
                                            </div>
                                            {/* Product Single Item */}
                                            <div className="product-inner-item">
                                                <article className="list-product mb-30px">
                                                    <div className="img-block">
                                                        <Link to="/DigitalShop" className="thumbnail">
                                                            <img className="first-img" src="assets/images/product-image/electronic/6.jpg" alt />
                                                        </Link>
                                                        <div className="quick-view">
                                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                                <i className="ion-ios-search-strong" />
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <ul className="product-flag">
                                                        <li className="new">New</li>
                                                    </ul>
                                                    <div className="product-decs">
                                                        <a className="inner-link" Link to="/DigitalShop"><span>ELECTRONICS</span></a>
                                                        <h2><Link to="/DigitalShop" className="product-link">samsung bluetooth</Link></h2>
                                                        <div className="rating-product">
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                        </div>
                                                        <div className="pricing-meta">
                                                            <ul>
                                                                <li className="old-price not-cut">€29.90</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div className="add-to-link">
                                                        <ul>
                                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                            <li>
                                                            <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                            </li>
                                                            <li>
                                                            <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </article>
                                            </div>
                                            {/* Product Single Item */}
                                            <div className="product-inner-item">
                                                <article className="list-product mb-30px">
                                                    <div className="img-block">
                                                        <Link to="/PixelPhone" className="thumbnail">
                                                            <img className="first-img" src="assets/images/product-image/electronic/7.jpg" alt />
                                                        </Link>
                                                        <div className="quick-view">
                                                            <Link to="/PixelPhone" className="thumbnail">
                                                        </Link>
                                                        <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                                <i className="ion-ios-search-strong" />
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <ul className="product-flag">
                                                        <li className="new">New</li>
                                                    </ul>
                                                    <div className="product-decs">
                                                        <a className="inner-link" Link to="/PixelPhone"><span>MOBILE</span></a>
                                                        <h2><Link to="/PixelPhone" className="product-link">PIXEL PHONE</Link></h2>
                                                        <div className="rating-product">
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                        </div>
                                                        <div className="pricing-meta">
                                                            <ul>
                                                                <li className="old-price">€35.90</li>
                                                                <li className="current-price">€34.11</li>
                                                                <li className="discount-price">-5%</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div className="add-to-link">
                                                        <ul>
                                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                            <li>
                                                            <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                            </li>
                                                            <li>
                                                            <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </article>
                                            </div>
                                            {/* Product Single Item */}
                                            <div className="product-inner-item">
                                                <article className="list-product mb-30px">
                                                    <div className="img-block">
                                                        <Link to="/DigitalShop" className="thumbnail">
                                                            <img className="first-img" src="assets/images/product-image/electronic/5.jpg" alt />
                                                        </Link>
                                                        <div className="quick-view">
                                                            <Link to="/DigitalShop" className="thumbnail">
                                                        </Link><a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                                <i className="ion-ios-search-strong" />
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <ul className="product-flag">
                                                        <li className="new">New</li>
                                                    </ul>
                                                    <div className="product-decs">
                                                        <a className="inner-link" Link to="/DigitalShop"><span>ELECTRONICS</span></a>
                                                        <h2><Link to="/DigitalShop" className="product-link">SAMSUNG HEADPHONES</Link></h2>
                                                        <div className="rating-product">
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                        </div>
                                                        <div className="pricing-meta">
                                                            <ul>
                                                                <li className="old-price">€11.90</li>
                                                                <li className="current-price">€10.12</li>
                                                                <li className="discount-price">-15%</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div className="add-to-link">
                                                        <ul>
                                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                            <li>
                                                            <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                            </li>
                                                            <li>
                                                            <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </article>
                                            </div>
                                            {/* Product Single Item */}
                                            <div className="product-inner-item">
                                                <article className="list-product mb-30px">
                                                    <div className="img-block">
                                                        <Link to="/DigitalShop" className="thumbnail">
                                                            <img className="first-img" src="assets/images/product-image/electronic/14.jpg" alt />
                                                            <img className="second-img" src="assets/images/product-image/electronic/2.jpg" alt />
                                                        </Link>
                                                        <div className="quick-view">
                                                            <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                                                                <i className="ion-ios-search-strong" />
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <ul className="product-flag">
                                                        <li className="new">New</li>
                                                    </ul>
                                                    <div className="product-decs">
                                                        <a className="inner-link" Link to="/DigitalShop"><span>ELECTRONIC</span></a>
                                                        <h2><Link to="/DigitalShop" className="product-link">SMART WATCH</Link></h2>
                                                        <div className="rating-product">
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                            <i className="ion-android-star" />
                                                        </div>
                                                        <div className="pricing-meta">
                                                            <ul>
                                                                <li className="old-price not-cut">€11.90</li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div className="add-to-link">
                                                        <ul>
                                                            <li className="cart"><Link to="/Cart" className="cart-btn">ADD TO CART </Link></li>
                                                            <li>
                                                            <Link to="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                                                            </li>
                                                            <li>
                                                            <Link to="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </article>
                                            </div>
                                            {/* Product Slider End */}
                                        </div>
                                    </div>
                                </div>
                                {/* 1st tab end */}
                                {/* 2nd tab start */}
                            </div>
                        </div>
                    </div>
                    {/* Product Slider End */}
                    {/* 4rd tab end */}
                </section>
                {/* Category Tab Area end */}
                {/* Blog area Start */}
                <section className="blog-area mb-30px mt-30">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                {/* Section title */}
                                <div className="section-title">
                                    <h2>Latest Blogs</h2>
                                    <p>Present posts in a best way to highlight interesting moments of your blog.</p>
                                </div>
                                {/* Section title */}
                            </div>
                        </div>
                        {/* Blog Slider Start */}
                        <div className="blog-slider-active owl-carousel owl-nav-style">
                            {/* single item */}
                            <article className="blog-post">
                                <div className="blog-post-top">
                                    <div className="blog-img">
                                        <img src="assets/images/blog-image/blog-5.jpg" alt />
                                    </div>
                                </div>
                                <div className="blog-post-content d-flex">
                                    <div className="blog-post-content-cell">
                                        <Link to="/PixelPhone" className="blog-meta">Digital</Link>
                                        <h4 className="blog-post-heading"><Link to="/PixelPhone">PIXEL</Link></h4>
                                        <p className="blog-text">
                                            GOOGLE PIXEL INOVATING IDEAS
                                        </p>
                                        <a className="read-more-btn" Link to="/PixelPhone"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
                                    </div>
                                </div>
                            </article>
                            {/* single item */}
                            <article className="blog-post">
                                <div className="blog-post-top">
                                    <div className="blog-img">
                                        <img src="assets/images/blog-image/blog-6.jpg" alt />
                                    </div>
                                </div>
                                <div className="blog-post-content d-flex">
                                    <div className="blog-post-content-cell">
                                        <Link to="/AlphonsoMangoes" className="blog-meta">Digital</Link>
                                        <h4 className="blog-post-heading"><Link to="/AlphonsoMangoes">ALPHONSO</Link></h4>
                                        <p className="blog-text">
                                            KING OF MANGOES
                                        </p>
                                        <a className="read-more-btn" Link to="/AlphonsoMangoes"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
                                    </div>
                                </div>
                            </article>
                            {/* single item */}
                            <article className="blog-post">
                                <div className="blog-post-top">
                                    <div className="blog-img">
                                        <img src="assets/images/blog-image/blog-7.jpg" alt />
                                    </div>
                                </div>
                                <div className="blog-post-content d-flex">
                                    <div className="blog-post-content-cell">
                                        <Link to="/DigitalShop" className="blog-meta">Digital</Link>
                                        <h4 className="blog-post-heading"><Link to="/DigitalShop">GO PRO HERO 9</Link></h4>
                                        <p className="blog-text">
                                            #MORE EVERYTHING
                                        </p>
                                        <a className="read-more-btn" Link to="/DigitalShop"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
                                    </div>
                                </div>
                            </article>
                            {/* single item */}
                            <article className="blog-post">
                                <div className="blog-post-top">
                                    <div className="blog-img">
                                        <img src="assets/images/blog-image/blog-8.jpg" alt />
                                    </div>
                                </div>
                                <div className="blog-post-content">
                                    <Link to="/DigitalShop" className="blog-meta">Fashion</Link>
                                    <h4 className="blog-post-heading"><Link to="/DigitalShop">This is Foruth Post For XipBlog</Link></h4>
                                    <p className="blog-text">
                                        Lorem Ipsum is simply dummy text of the printing and typeSettings industry. Lorem Ipsum has been the industrys ...
                                    </p>
                                    <a className="read-more-btn"Link to="/DigitalShop"> Read More <i className="ion-android-arrow-dropright-circle" /></a>
                                </div>
                            </article>
                            {/* single item */}
                        </div>
                        {/* Blog Slider Start */}
                    </div>
                </section>
                {/* Blog Area End */}
                {/* Brand area start */}
                <div className="brand-area">
                    <div className="container">
                        <div className="brand-slider owl-carousel owl-nav-style owl-nav-style-2">
                            <div className="brand-slider-item">
                                <a href="#"><img src="assets/images/brand-logo/1.jpg" alt /></a>
                            </div>
                            <div className="brand-slider-item">
                                <a href="#"><img src="assets/images/brand-logo/2.jpg" alt /></a>
                            </div>
                            <div className="brand-slider-item">
                                <a href="#"><img src="assets/images/brand-logo/3.jpg" alt /></a>
                            </div>
                            <div className="brand-slider-item">
                                <a href="#"><img src="assets/images/brand-logo/4.jpg" alt /></a>
                            </div>
                            <div className="brand-slider-item">
                                <a href="#"><img src="assets/images/brand-logo/5.jpg" alt /></a>
                            </div>
                            <div className="brand-slider-item">
                                <a href="#"><img src="assets/images/brand-logo/1.jpg" alt /></a>
                            </div>
                            <div className="brand-slider-item">
                                <a href="#"><img src="assets/images/brand-logo/2.jpg" alt /></a>
                            </div>
                        </div>
                    </div>
                </div>
                {/* Brand area end */}
            </div>

        )
    }
}

export default Digital;