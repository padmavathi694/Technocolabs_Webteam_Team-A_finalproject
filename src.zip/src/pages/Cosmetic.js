import React from 'react';
import {Link} from 'react-router-dom';
class Cosmetic extends React.Component{

    render()
    {
        return(
            <div>
                 
           {/* Brand area end */}<div>
</div>

  {/* Slider Arae Start */}
  <div className="slider-area">
    <div className="slider-active-3 owl-carousel slider-hm8 owl-dot-style">
      {/* Slider Single Item Start */}
      <div className="slider-height-6 d-flex align-items-start justify-content-start bg-img" style={{backgroundImage: 'url(assets/images/slider-image/sample-9.jpg)'}}>
        <div className="container">
          <div className="slider-content-5 slider-animated-1 text-left">
            <span className="animated">DISCOVER OUR BESTSELLING</span>
            <h1 className="animated">
              Anti-Oxidant Marine <br />
              Face Creams
            </h1>
            <a><Link to ="/Shopcos" className="shop-btn animated">SHOP NOW</Link></a>
          </div>
        </div>
      </div>
      {/* Slider Single Item End */}
      {/* Slider Single Item Start */}
      <div className="slider-height-6 d-flex align-items-start justify-content-start bg-img" style={{backgroundImage: 'url(assets/images/slider-image/sample-10.jpg)'}}>
        <div className="container">
          <div className="slider-content-5 slider-animated-1 text-left">
            <span className="animated">RADIANT. YOUTHFUL. GLOWING</span>
            <h1 className="animated">
              Making Beautiful<br />
              Skin A Reality
            </h1>
            <a><Link to ="/Shopcos" className="shop-btn animated">SHOP NOW</Link></a>
          </div>
        </div>
      </div>
      {/* Slider Single Item End */}
    </div>
  </div>
  {/* Slider Arae End */}
  {/* Static Area Start */}
  <section className="static-area mtb-60px">
    <div className="container">
      <div className="static-area-wrap">
        <div className="row">
          {/* Static Single Item Start */}
          <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
            <div className="single-static pb-res-md-0 pb-res-sm-0 pb-res-xs-0">
              <img src="assets/images/icons/static-icons-1.png" alt className="img-responsive" />
              <div className="single-static-meta">
                <h4>Free Shipping</h4>
                <p>On all orders over $75.00</p>
              </div>
            </div>
          </div>
          {/* Static Single Item End */}
          {/* Static Single Item Start */}
          <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
            <div className="single-static pb-res-md-0 pb-res-sm-0 pb-res-xs-0 pt-res-xs-20">
              <img src="assets/images/icons/static-icons-2.png" alt className="img-responsive" />
              <div className="single-static-meta">
                <h4>Free Returns</h4>
                <p>Returns are free within 9 days</p>
              </div>
            </div>
          </div>
          {/* Static Single Item End */}
          {/* Static Single Item Start */}
          <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
            <div className="single-static pt-res-md-30 pb-res-sm-30 pb-res-xs-0 pt-res-xs-20">
              <img src="assets/images/icons/static-icons-3.png" alt className="img-responsive" />
              <div className="single-static-meta">
                <h4>100% Payment Secure</h4>
                <p>Your payment are safe with us.</p>
              </div>
            </div>
          </div>
          {/* Static Single Item End */}
          {/* Static Single Item Start */}
          <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
            <div className="single-static pt-res-md-30 pb-res-sm-30 pt-res-xs-20">
              <img src="assets/images/icons/static-icons-4.png" alt className="img-responsive" />
              <div className="single-static-meta">
                <h4>Support 24/7</h4>
                <p>Contact us 24 hours a day</p>
              </div>
            </div>
          </div>
          {/* Static Single Item End */}
        </div>
      </div>
    </div>
  </section>
  {/* Static Area End */}
  {/* Banner Area Start */}
  <div className="banner-3-area">
    <div className="container">
      <div className="row">
        <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 mb-res-xs-30 mb-res-sm-30">
          <div className="banner-wrapper">
            <a><Link to ="/Shopcos"></Link><img src="assets/images/banner-image/11.jpg" alt /></a>
          </div>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div className="banner-wrapper mb-30px">
            <a><Link to ="/Shopcos"></Link><img src="assets/images/banner-image/12.jpg" alt /></a>
          </div>
          <div className="banner-wrapper">
            <a><Link to ="/Shopcos"></Link><img src="assets/images/banner-image/13.jpg" alt /></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Banner Area End */}
  {/* Hot deal area Start */}
  <section className="hot-deal-area">
    <div className="container">
      <div className="row">
        <div className="col-xs-12 col-sm-12 col-md-5 col-lg-5 col-xl-4">
          <div className="row">
            <div className="col-md-12">
              {/* Section Title */}
              <div className="section-title">
                <h2>Hot Deals</h2>
                <p>CHECK OUT OUR HOT DEALS TODAY</p>
              </div>
              {/* Section Title End*/}
            </div>
          </div>
          {/* Hot Deal Slider Start */}
          <div className="hot-deal owl-carousel owl-nav-style">
            {/*  Single item */}
            <article className="list-product">
              <div className="img-block">
                <a href="single-product-concealor.html" className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/cosmatic/1.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/cosmatic/1.jpg" alt />
                </a>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <ul className="product-flag">
                <li className="new">New</li>
              </ul>
              <div className="product-decs">
                <Link to ="/Concealor" className="inner-link" ><span>MAKE UP</span></Link>
                <h2><Link to ="/Concealor"
                 className="product-link">Concealor</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price">€18.90</li>
                    <li className="current-price">€34.21</li>
                    <li className="discount-price">-5%</li>
                  </ul>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                      <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                      <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="in-stock">Availability: <span>30 In Stock</span></div>
              <div className="clockdiv">
                <div className="title_countdown">Hurry Up! Offers ends in:</div>
                <div data-countdown="2021/06/14" />
              </div>
            </article>
            {/*  Single item */}
            <article className="list-product">
              <div className="img-block">
                <a href="single-product-mini makeup.html" className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/cosmatic/2.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/cosmatic/2.jpg" alt />
                </a>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <ul className="product-flag">
                <li className="new">New</li>
              </ul>
              <div className="product-decs">
                <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                <h2><Link to ="/Minimakeup"
                className="product-link">Minimakeup</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price">€18.90</li>
                    <li className="current-price">€34.21</li>
                    <li className="discount-price">-5%</li>
                  </ul>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="in-stock">Availability: <span>40 In Stock</span></div>
              <div className="clockdiv">
                <div className="title_countdown">Hurry Up! Offers ends in:</div>
                <div data-countdown="2021/06/16" />
              </div>
            </article>
            {/*  Single item */}
            <article className="list-product">
              <div className="img-block">
                <a href="single-product-lipgloss.html" className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/cosmatic/15.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/cosmatic/15.jpg" alt />
                </a>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <ul className="product-flag">
                <li className="new">New</li>
              </ul>
              <div className="product-decs">
                <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                <h2><Link to ="/Lipgloss"
                className="product-link">Lipgloss</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price">€18.90</li>
                    <li className="current-price">€34.21</li>
                    <li className="discount-price">-5%</li>
                  </ul>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="in-stock">Availability: <span>9 In Stock</span></div>
              <div className="clockdiv">
                <div className="title_countdown">Hurry Up! Offers ends in:</div>
                <div data-countdown="2021/06/16" />
              </div>
            </article>
            {/*  Single item */}
            <article className="list-product">
              <div className="img-block">
                <a href="single-product-pink clay soap.html" className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/cosmatic/5.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/cosmatic/5.jpg" alt />
                </a>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <ul className="product-flag">
                <li className="new">New</li>
              </ul>
              <div className="product-decs">
                <a className="inner-link" href="shop-4-column.html"><span>SOAP</span></a>
                <h2><Link to ="/Pinkclaysoap"
                className="product-link">PINK CLAY</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price">€18.90</li>
                    <li className="current-price">€34.21</li>
                    <li className="discount-price">-5%</li>
                  </ul>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart"className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="in-stock">Availability: <span>29 In Stock</span></div>
              <div className="clockdiv">
                <div className="title_countdown">Hurry Up! Offers ends in:</div>
                <div data-countdown="2021/06/15" />
              </div>
            </article>
            {/*  Single item */}
          </div>
          {/* Hot Deal Slider End */}
        </div>
        {/* New Arrivals Area Start */}
        <div className="col-xs-12 col-sm-12 col-md-7 col-lg-7 col-xl-8">
          <div className="row">
            <div className="col-md-12">
              {/* Section Title */}
              <div className="section-title ml-0px mt-res-sx-30px">
                <h2>New Arrivals</h2>
                <p>PRESENTING THE NEW ARRIVALS OF THE WEEK</p>
              </div>
              {/* Section Title */}
            </div>
          </div>
          {/* New Product Slider Start */}
          <div className="new-product-slider owl-carousel owl-nav-style">
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <a href="single-product-concealor.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/cosmatic/1.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/cosmatic/1.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" href="shop-4-column.html"><span>MAKE UP</span></a>
                  <h2><Link to ="/Concealor"
                className="product-link">Concealor</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">€23.90</li>
                      <li className="current-price">€21.51</li>
                      <li className="discount-price">-10%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"> <i className="ion-android-favorite-outline" /></Link>
                     </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </article>
              <article className="list-product">
                <div className="img-block">
                  <a href="shop-3-column.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/cosmatic/6.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/cosmatic/6.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                  <h2><Link to ="/Shopcos"
                className="product-link">Faces Canada expert ultra matte</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">€35.90</li>
                      <li className="current-price">€34.11</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <a href="single-product-lipgloss.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/cosmatic/8.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/cosmatic/8.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" href="shop-3-column.html"><span>MAKE-UP</span></a>
                  <h2><Link to ="/Lipgloss"
                className="product-link">Lipgloss</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">€29.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </article>
              <article className="list-product">
                <div className="img-block">
                  <a href="shop-3-column.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/cosmatic/9.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/cosmatic/9.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                  <h2><Link to ="/Shopcos" className="product-link">LIPSTICK</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">€29.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart"className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <a href="shop-3-column.html" className="thumbnail">
                  </a><a href className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/cosmatic/3.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/cosmatic/2.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" href="shop-3-column.html"><span>MAKE-UP</span></a>
                  <h2><Link to ="/Shopcos" className="product-link">SKIN TONNER</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">€35.90</li>
                      <li className="current-price">€34.11</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </article>
              <article className="list-product">
                <div className="img-block">
                  <a href="shop-3-column.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/cosmatic/7.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/cosmatic/7.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                  <h2><Link to ="/Shopcos" className="product-link">FACE PACK BRUSH</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">€35.90</li>
                      <li className="current-price">€34.11</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <a href="shop-3-column.html" className="thumbnail">
                  </a><a href className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/cosmatic/5.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/cosmatic/5.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" href="shop-3-column.html"><span>SOAP</span></a>
                  <h2><Link to ="/Pinkclaysoap"
                className="product-link">PINK CLAY</Link></h2>
                  
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">€11.90</li>
                      <li className="current-price">€10.12</li>
                      <li className="discount-price">-15%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </article>
              <article className="list-product">
                <div className="img-block">
                  <a href="shop-3-column.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/cosmatic/10.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/cosmatic/10.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" href="shop-4-column.html"><span>NAIL</span></a>
                  <h2><Link to ="/Shopcos" className="product-link">NAIL POLISH REMOVER</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">€19.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link">
                  <ul>
                    <li className="cart"><Link to ="/Cart" className="cart-btn">ADD TO CART </Link></li>
                    <li>
                    <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                    </li>
                    <li>
                    <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                    </li>
                  </ul>
                </div>
              </article>
            </div>
          </div>
          {/* Product Slider End */}
        </div>
      </div>
    </div>
  </section>
  {/* Hot Deal Area End */}
  {/* Banner Area Start */}
  <div className="banner-area">
    <div className="container">
      <div className="row">
        <div className="col-md-3 col-xs-12">
          <div className="banner-wrapper">
            <a href="#"><img src="assets/images/banner-image/14.jpg" alt /></a>
          </div>
        </div>
        <div className="col-md-6 col-xs-12 mt-res-sx-30px">
          <div className="banner-wrapper">
            <a href="#"><img src="assets/images/banner-image/15.jpg" alt /></a>
          </div>
        </div>
        <div className="col-md-3 col-xs-12 mt-res-sx-30px">
          <div className="banner-wrapper">
            <a href="#"><img src="assets/images/banner-image/16.jpg" alt /></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Banner Area End */}
  {/* Feature Area Start */}
  <section className="feature-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          {/* Section Title */}
          <div className="section-title">
            <h2>Featured Products</h2>
            <p>THIS WEEKS FEATURED PRODUCTS</p>
          </div>
          {/* Section Title */}
        </div>
      </div>
      {/* Feature Slider Start */}
      <div className="feature-slider owl-carousel owl-nav-style">
        {/* Single Item */}
        <div className="feature-slider-item">
          <article className="list-product">
            <div className="img-block">
              <a href="shop-3-column.html" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/cosmatic/1.jpg" alt />
                <img className="second-img" src="assets/images/product-image/cosmatic/1.jpg" alt />
              </a>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
              <h2><Link to ="/Concealor"
                className="product-link">Concealor</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€29.90</li>
                </ul>
              </div>
            </div>
          </article>
          <article className="list-product">
            <div className="img-block">
              <a href="shop-3-column.html" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/cosmatic/15.jpg" alt />
                <img className="second-img" src="assets/images/product-image/cosmatic/15.jpg" alt />
              </a>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>EYES</span></a>
              <h2><Link to ="/Shopcos"
                className="product-link">Mascara</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€29.90</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
        {/* Single Item */}
        <div className="feature-slider-item">
          <article className="list-product">
            <div className="img-block">
              <a href="shop-3-column.html" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/cosmatic/14.jpg" alt />
                <img className="second-img" src="assets/images/product-image/cosmatic/7.jpg" alt />
              </a>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
              <h2><Link to ="/Shopcos"
                className="product-link">COMPACT FACE BRUSH</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€23.90</li>
                  <li className="current-price">€21.51</li>
                </ul>
              </div>
            </div>
          </article>
          <article className="list-product">
            <div className="img-block">
              <a href="shop-3-column.html" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/cosmatic/13.jpg" alt />
                <img className="second-img" src="assets/images/product-image/cosmatic/13.jpg" alt />
              </a>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
              <h2><Link to ="/Shopcos"
                className="product-link">MAKEUP BRUSH</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€23.90</li>
                  <li className="current-price">€21.51</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
        {/* Single Item */}
        <div className="feature-slider-item">
          <article className="list-product">
            <div className="img-block">
              <a href="shop-3-column.html" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/cosmatic/12.jpg" alt />
                <img className="second-img" src="assets/images/product-image/cosmatic/12.jpg" alt />
              </a>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>FACE</span></a>
              <h2><Link to ="/Shopcos"
                className="product-link">SUNSCREEN</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€11.90</li>
                  <li className="current-price">€10.12</li>
                </ul>
              </div>
            </div>
          </article>
          <article className="list-product">
            <div className="img-block">
              <a href="shop-3-column.html" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/cosmatic/19.jpg" alt />
                <img className="second-img" src="assets/images/product-image/cosmatic/19.jpg" alt />
              </a>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <div className="product-decs">
              <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
              <h2><Link to ="/Shopcos"
                className="product-link">LAKME LIPSTICK</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€18.90</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
        {/* Feature Slider End */}
      </div>
    </div></section>
  {/* Feature Area End */}
  {/* Banner Area 2 Start */}
  <div className="banner-area-2">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="banner-inner">
            <a href="shop-4-column.html"><img src="assets/images/banner-image/17.jpg" alt /></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Banner Area 2 End */}
  {/* Recent Add Product Area Start */}
  <section className="recent-add-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          {/* Section Title */}
          <div className="section-title">
            <h2>Recently Added</h2>
            <p>ECOLIFE HAS GOT A WHOLE NEW RANGE PRODUCTS FOR YOU!!!</p>
          </div>
          {/* Section Title */}
        </div>
      </div>
      {/* Recent Product slider Start */}
      <div className="recent-product-slider owl-carousel owl-nav-style">
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <a href="shop-3-column.html" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/cosmatic/2.jpg" alt />
              <img className="second-img" src="assets/images/product-image/cosmatic/3.jpg" alt />
            </a>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
            <h2><Link to ="/Shopcos"
                className="product-link">COMPACT FACE POWDER</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price">€23.90</li>
                <li className="current-price">€21.51</li>
                <li className="discount-price">-10%</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
              <li>
              <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <a href="shop-3-column.html" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/cosmatic/12.jpg" alt />
              <img className="second-img" src="assets/images/product-image/cosmatic/12.jpg" alt />
            </a>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>FACE</span></a>
            <h2><Link to ="/Shopcos"
                className="product-link">SUNSCREEN</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price">€35.90</li>
                <li className="current-price">€34.21</li>
                <li className="discount-price">-5%</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
              <li>
              <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <a href="shop-3-column.html" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/cosmatic/17.jpg" alt />
              <img className="second-img" src="assets/images/product-image/cosmatic/17.jpg" alt />
            </a>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>NAIL</span></a>
            <h2><Link to ="/Shopcos"
                className="product-link">NAIL POLISH</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price not-cut">€29.90</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
              <li>
              <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <a href="shop-3-column.html" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/cosmatic/13.jpg" alt />
              <img className="second-img" src="assets/images/product-image/cosmatic/13.jpg" alt />
            </a>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>FACE</span></a>
            <h2><Link to ="/Shopcos"
                className="product-link">FACE BRUSH</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price not-cut">€29.90</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
              <li>
              <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <a href="shop-3-column.html" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/cosmatic/18.jpg" alt />
              <img className="second-img" src="assets/images/product-image/cosmatic/18.jpg" alt />
            </a>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>FACE</span></a>
            <h2><Link to ="/Shopcos"
                className="product-link">LIPSTICK</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price not-cut">€29.90</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
              <li>
              <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
        {/* Single Item */}
        <article className="list-product">
          <div className="img-block">
            <a href="shop-3-column.html" className="thumbnail">
              <img className="first-img" src="assets/images/product-image/cosmatic/5.jpg" alt />
              <img className="second-img" src="assets/images/product-image/cosmatic/5.jpg" alt />
            </a>
            <div className="quick-view">
              <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                <i className="ion-ios-search-strong" />
              </a>
            </div>
          </div>
          <ul className="product-flag">
            <li className="new">New</li>
          </ul>
          <div className="product-decs">
            <a className="inner-link" href="shop-4-column.html"><span>beauty</span></a>
            <h2><Link to ="/Pinkclaysoap"
                className="product-link">PINK CLAY</Link></h2>
            <div className="rating-product">
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
              <i className="ion-android-star" />
            </div>
            <div className="pricing-meta">
              <ul>
                <li className="old-price">€12.90</li>
                <li className="current-price">€10.21</li>
                <li className="discount-price">-10%</li>
              </ul>
            </div>
          </div>
          <div className="add-to-link">
            <ul>
              <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
              <li>
              <Link to = "/Wishlist"><i className="ion-android-favorite-outline" /></Link>
              </li>
              <li>
              <Link to = "/Compare"><i className="ion-ios-shuffle-strong" /></Link>
              </li>
            </ul>
          </div>
        </article>
       {/* Single Item */}
      </div>
      {/* Recent product slider end */}
    </div>
  </section>
  {/* Recent product area end */}
  </div>
        )
    }
    
}
export default Cosmetic;