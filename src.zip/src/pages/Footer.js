//import { react } from '@babel/types';
//import React , {Component} from 'react';
//import {Link} from 'react-router-dom';
import React from "react";
class Footer extends React.Component{
    render(){
        return(
           <div>
<div>
  {/* Brand area start */}
  <div className="brand-area">
    <div className="container">
      <div className="brand-slider owl-carousel owl-nav-style owl-nav-style-2">
        <div className="brand-slider-item">
          <a href="#"><img src="assets/images/brand-logo/1.jpg" alt /></a>
        </div>
        <div className="brand-slider-item">
          <a href="#"><img src="assets/images/brand-logo/2.jpg" alt /></a>
        </div>
        <div className="brand-slider-item">
          <a href="#"><img src="assets/images/brand-logo/3.jpg" alt /></a>
        </div>
        <div className="brand-slider-item">
          <a href="#"><img src="assets/images/brand-logo/4.jpg" alt /></a>
        </div>
        <div className="brand-slider-item">
          <a href="#"><img src="assets/images/brand-logo/5.jpg" alt /></a>
        </div>
        <div className="brand-slider-item">
          <a href="#"><img src="assets/images/brand-logo/1.jpg" alt /></a>
        </div>
        <div className="brand-slider-item">
          <a href="#"><img src="assets/images/brand-logo/2.jpg" alt /></a>
        </div>
      </div>
    </div>
  </div>
  {/* Brand area end */}
  {/* Category Product  Area start*/}
  {/* Category Product  Area end*/}
  {/* Footer Area start */}
  <footer className="footer-area">
    <div className="footer-top">
      <div className="container">
        <div className="row">
          {/* footer single wedget */}
          <div className="col-md-6 col-lg-4">
            {/* footer logo */}
            <div className="footer-logo">
              <a href="index.html"><img src="assets/images/logo/logo-furniture.jpg" alt /></a>
            </div>
            {/* footer logo */}
            <div className="about-footer">
              <p className="text-info">We are a team of designers and developers that create high quality HTML template</p>
              <div className="need-help">
                <p className="phone-info">
                  NEED HELP?
                  <span>
                    (+800) 345 678 <br />
                    (+800) 123 456
                  </span>
                </p>
              </div>
              <div className="social-info">
                <ul>
                  <li>
                    <a href="#"><i className="ion-social-facebook" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-twitter" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-youtube" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-google" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-instagram" /></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          {/* footer single wedget */}
          <div className="col-md-6 col-lg-2 mt-res-sx-30px mt-res-md-30px">
            <div className="single-wedge">
              <h4 className="footer-herading">Information</h4>
              <div className="footer-links">
                <ul>
                  <li><a href="#">Delivery</a></li>
                  <li><a href="about.html">About Us</a></li>
                  <li><a href="#">Secure Payment</a></li>
                  <li><a href="contact.html">Contact Us</a></li>
                  <li><a href="#">Sitemap</a></li>
                  <li><a href="#">Stores</a></li>
                </ul>
              </div>
            </div>
          </div>
          {/* footer single wedget */}
          <div className="col-md-6 col-lg-2 mt-res-md-50px mt-res-sx-30px mt-res-md-30px">
            <div className="single-wedge">
              <h4 className="footer-herading">Custom Links</h4>
              <div className="footer-links">
                <ul>
                  <li><a href="#">Legal Notice</a></li>
                  <li><a href="#">Prices Drop</a></li>
                  <li><a href="#">New Products</a></li>
                  <li><a href="#">Best Sales</a></li>
                  <li><a href="login.html">Login</a></li>
                  <li><a href="my-account.html">My Account</a></li>
                </ul>
              </div>
            </div>
          </div>
          {/* footer single wedget */}
          <div className="col-md-6 col-lg-4 mt-res-md-50px mt-res-sx-30px mt-res-md-30px">
            <div className="single-wedge">
              <h4 className="footer-herading">Newsletter</h4>
              <div className="subscrib-text">
                <p>You may unsubscribe at any moment. For that purpose, please find our contact info in the legal notice.</p>
              </div>
              <div id="mc_embed_signup" className="subscribe-form">
                <form id="mc-embedded-subscribe-form" className="validate" noValidate target="_blank" name="mc-embedded-subscribe-form" method="post" action="http://devitems.us11.list-manage.com/subscribe/post?u=6bbb9b6f5827bd842d9640c82&id=05d85f18ef">
                  <div id="mc_embed_signup_scroll" className="mc-form">
                    <input className="email" type="email" required placeholder="Enter your email here.." name="EMAIL" defaultValue />
                    <div className="mc-news" aria-hidden="true" style={{position: 'absolute', left: '-5000px'}}>
                      <input type="text" defaultValue tabIndex={-1} name="b_6bbb9b6f5827bd842d9640c82_05d85f18ef" />
                    </div>
                    <div className="clear">
                      <input id="mc-embedded-subscribe" className="button" type="submit" name="subscribe" defaultValue="Sign Up" />
                    </div>
                  </div>
                </form>
              </div>
              <div className="img_app">
                <a href="#"><img src="assets/images/icons/app_store.png" alt /></a>
                <a href="#"><img src="assets/images/icons/google_play.png" alt /></a>
              </div>
            </div>
          </div>
          {/* footer single wedget */}
        </div>
      </div>
    </div>
    {/*  Footer Bottom Area start */}
    <div className="footer-bottom">
      <div className="container">
        <div className="row">
          <div className="col-md-6 col-lg-4">
            <p className="copy-text">Copyright © <a href="https://hasthemes.com/"> HasThemes</a>. All Rights Reserved</p>
          </div>
          <div className="col-md-6 col-lg-8">
            <img className="payment-img" src="assets/images/icons/payment.png" alt />
          </div>
        </div>
      </div>
    </div>
    {/*  Footer Bottom Area End*/}
  </footer>
  {/*  Footer Area End */}
  {/* Modal */}
  <div className="modal fade" id="exampleModal" tabIndex={-1} role="dialog">
    <div className="modal-dialog" role="document">
      <div className="modal-content">
        <div className="modal-header">
          <button type="button" className="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
        </div>
        <div className="modal-body">
          <div className="row">
            <div className="col-md-5 col-sm-12 col-xs-12">
              <div className="tab-content quickview-big-img">
                <div id="pro-1" className="tab-pane fade show active">
                  <img src="assets/images/product-image/furniture/1.jpg" alt />
                </div>
                <div id="pro-2" className="tab-pane fade">
                  <img src="assets/images/product-image/furniture/2.jpg" alt />
                </div>
                <div id="pro-3" className="tab-pane fade">
                  <img src="assets/images/product-image/furniture/3.jpg" alt />
                </div>
                <div id="pro-4" className="tab-pane fade">
                  <img src="assets/images/product-image/furniture/4.jpg" alt />
                </div>
              </div>
              {/* Thumbnail Large Image End */}
              {/* Thumbnail Image End */}
              <div className="quickview-wrap mt-15">
                <div className="quickview-slide-active owl-carousel nav owl-nav-style owl-nav-style-2" role="tablist">
                  <a className="active" data-toggle="tab" href="#pro-1"><img src="assets/images/product-image/furniture/1.jpg" alt /></a>
                  <a data-toggle="tab" href="#pro-2"><img src="assets/images/product-image/furniture/2.jpg" alt /></a>
                  <a data-toggle="tab" href="#pro-3"><img src="assets/images/product-image/furniture/3.jpg" alt /></a>
                  <a data-toggle="tab" href="#pro-4"><img src="assets/images/product-image/furniture/4.jpg" alt /></a>
                </div>
              </div>
            </div>
            <div className="col-md-7 col-sm-12 col-xs-12">
              <div className="product-details-content quickview-content">
                <h2>Originals Kaval Windbr</h2>
                <p className="reference">Reference:<span> demo_17</span></p>
                <div className="pro-details-rating-wrap">
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <span className="read-review"><a className="reviews" href="#">Read reviews (1)</a></span>
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price not-cut">€18.90</li>
                  </ul>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipisic elit eiusm tempor incidid ut labore et dolore magna aliqua. Ut enim ad minim venialo quis nostrud exercitation ullamco</p>
                <div className="pro-details-size-color">
                  <div className="pro-details-color-wrap">
                    <span>Color</span>
                    <div className="pro-details-color-content">
                      <ul>
                        <li className="blue" />
                        <li className="maroon active" />
                      </ul>
                    </div>
                  </div>
                </div>
                <div className="pro-details-quality">
                  <div className="cart-plus-minus">
                    <input className="cart-plus-minus-box" type="text" name="qtybutton" defaultValue={1} />
                  </div>
                  <div className="pro-details-cart btn-hover">
                    <a href="#"> + Add To Cart</a>
                  </div>
                </div>
                <div className="pro-details-wish-com">
                  <div className="pro-details-wishlist">
                    <a href="#"><i className="ion-android-favorite-outline" />Add to wishlist</a>
                  </div>
                  <div className="pro-details-compare">
                    <a href="#"><i className="ion-ios-shuffle-strong" />Add to compare</a>
                  </div>
                </div>
                <div className="pro-details-social-info">
                  <span>Share</span>
                  <div className="social-info">
                    <ul>
                      <li>
                        <a href="#"><i className="ion-social-facebook" /></a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-social-twitter" /></a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-social-google" /></a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-social-instagram" /></a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Modal end */}
</div>


           </div>
        );
    }
}
export default Footer;