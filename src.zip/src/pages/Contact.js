import React from 'react';
import {Link} from 'react-router-dom';
  class Contact extends React.Component{
  render(){
  return(
      <div>
<div>
  {/* Breadcrumb Area start */}
  <section className="breadcrumb-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="breadcrumb-content">
            <h1 className="breadcrumb-hrading">Contact Page</h1>
            <ul className="breadcrumb-links">
              <li><a href="index.html">Home</a></li>
              <li>Contact Us</li>
              <p><b>HAVE A QUERY???FEEL FREE TO CONNECT WITH US!</b></p>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Area End */}
  {/* contact area start */}
  <div className="contact-area mtb-60px">
    <div className="container">
      <div className="contact-map mb-10">
        <div id="mapid" />
      </div>
      <div className="custom-row-2">
        <div className="col-lg-4 col-md-5">
          <div className="contact-info-wrap">
            <div className="single-contact-info">
              <div className="contact-icon">
                <i className="fa fa-phone" />
              </div>
              <div className="contact-info-dec">
                <p>+012 345 678 102</p>
                <p>+012 345 678 102</p>
              </div>
            </div>
            <div className="single-contact-info">
              <div className="contact-icon">
                <i className="fa fa-globe" />
              </div>
              <div className="contact-info-dec">
                <p><a href="#">ecolife@email.com</a></p>
                <p><a href="#">ecolife.com</a></p>
              </div>
            </div>
            <div className="single-contact-info">
              <div className="contact-icon">
                <i className="fa fa-map-marker" />
              </div>
              <div className="contact-info-dec">
                <p>Banjara Hills</p>
                <p>Hyderbad,Telanagana</p>
              </div>
            </div>
            <div className="contact-social">
              <h3>Follow Us</h3>
              <div className="social-info">
                <ul>
                  <li>
                    <a href="#"><i className="ion-social-facebook" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-twitter" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-youtube" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-google" /></a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-social-instagram" /></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="col-lg-8 col-md-7">
          <div className="contact-form">
            <div className="contact-title mb-30">
              <h2>Get In Touch</h2>
            </div>
            <form className="contact-form-style" id="contact-form" action="https://htmldemo.hasthemes.com/ecolife-preview/ecolife/assets/php/mail.php" method="post">
              <div className="row">
                <div className="col-lg-6">
                  <input name="name" placeholder="Name*" type="text" />
                </div>
                <div className="col-lg-6">
                  <input name="email" placeholder="Email*" type="email" />
                </div>
                <div className="col-lg-12">
                  <input name="subject" placeholder="Subject*" type="text" />
                </div>
                <div className="col-lg-12">
                  <textarea name="message" placeholder="Your Message*" defaultValue={""} />
                  <button className="submit" type="submit">SEND</button>
                </div>
              </div>
            </form>
            <p className="form-messege" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

          </div>
  )
  }
}
export default Contact;