import React from 'react';
import {Link} from 'react-router-dom';
class Shopcos extends React.Component{

    render()
    {
        return(
            <div>
                <div>
  {/* Breadcrumb Area start */}
  <section className="breadcrumb-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="breadcrumb-content">
            <h1 className="breadcrumb-hrading">Shop Page</h1>
            <ul className="breadcrumb-links">
              <li><a href="index.html">Home</a></li>
              <li>Shop Grid</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Area End */}
  {/* Shop Category Area End */}
  <div className="shop-category-area">
    <div className="container">
      <div className="row">
        <div className="col-lg-12 col-md-12">
          {/* Shop Top Area Start */}
          <div className="shop-top-bar">
            {/* Left Side start */}
            <div className="shop-tab nav mb-res-sm-15">
              <a className="active" href="#shop-1" data-toggle="tab">
                <i className="fa fa-th show_grid" />
              </a>
              <a href="#shop-2" data-toggle="tab">
                <i className="fa fa-list-ul" />
              </a>
              <p>There Are 17 Products.</p>
            </div>
            {/* Left Side End */}
            {/* Right Side Start */}
            <div className="select-shoing-wrap">
              <div className="shot-product">
                <p>Sort By:</p>
              </div>
              <div className="shop-select">
                <select>
                  <option value>Sort by newness</option>
                  <option value>A to Z</option>
                  <option value> Z to A</option>
                  <option value>In stock</option>
                </select>
              </div>
            </div>
            {/* Right Side End */}
          </div>
          {/* Shop Top Area End */}
          {/* Shop Bottom Area Start */}
          <div className="shop-bottom-area mt-35">
            {/* Shop Tab Content Start */}
            <div className="tab-content jump">
              {/* Tab One Start */}
              <div id="shop-1" className="tab-pane active">
                <div className="row">
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/1.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/1.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                        <h2><Link to ="/Concealor">Concealor</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price">€18.90</li>
                            <li className="current-price">€34.21</li>
                            <li className="discount-price">-5%</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/3.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/3.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                        <h2><Link to ="/Minimakeup"
                className="product-link">Minimakeup</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price">€18.90</li>
                            <li className="current-price">€15.12</li>
                            <li className="discount-price">-20%</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/4.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/4.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>EYE MAKE UP</span></a>
                        <h2><Link to ="/Minimakeup"
                className="product-link">Eye makeup</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price not-cut">€18.90</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/5.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/5.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>SOAP</span></a>
                        <h2><Link to ="/Pinkclaysoap"
                className="product-link">Pinkclaysoap</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price not-cut">€18.90</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/8.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/8.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                        <h2><Link to ="/Lipgloss"
                className="product-link">Lip balm</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price not-cut">€18.90</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/9.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/9.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                        <h2><Link to ="/Lipgloss"
                className="product-link">Lipstick</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price not-cut">€18.90</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/2.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/2.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                        <h2><Link to ="/Minimakeup"
                className="product-link">Compact natural powder</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price not-cut">€18.90</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/7.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/7.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                        <h2><Link to ="/Cosmetic"
                className="product-link">Face pack brush</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price not-cut">€29.90</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/10.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/10.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>NAIL</span></a>
                        <h2><Link to ="/Cosmetic"
                className="product-link">Lakme nail polish REMOVER</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price">€23.90</li>
                            <li className="current-price">€21.51</li>
                            <li className="discount-price">-10%</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/15.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/15.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>EYES</span></a>
                        <h2><Link to ="/Cosmetic"
                className="product-link">MASCARA</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price not-cut">€18.90</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn">ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/14.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/14.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                        <h2><Link to ="/Minimakeup"
                className="product-link">Compact Face brushes</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price">€11.90</li>
                            <li className="current-price">€10.12</li>
                            <li className="discount-price">-15%</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/12.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/12.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>FACE</span></a>
                        <h2><Link to ="/Lipgloss"
                className="product-link">SUNSCREEN</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price">€35.90</li>
                            <li className="current-price">€34.11</li>
                            <li className="discount-price">-5%</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/19.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/19.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>MAKE-UP</span></a>
                        <h2><Link to ="/Minimakeup"
                className="product-link">Lakme LIPSTICK</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price">€18.90</li>
                            <li className="current-price">€34.21</li>
                            <li className="discount-price">-5%</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/18.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/18.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>FACE</span></a>
                        <h2><Link to ="/Pinkclaysoap"
                className="product-link">LIPSTICK</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price">€18.90</li>
                            <li className="current-price">€15.12</li>
                            <li className="discount-price">-20%</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                  <div className="col-md-4 col-sm-6">
                    <article className="list-product">
                      <div className="img-block">
                        <a href="single-product.html" className="thumbnail">
                          <img className="first-img" src="assets/images/product-image/cosmatic/13.jpg" alt />
                          <img className="second-img" src="assets/images/product-image/cosmatic/13.jpg" alt />
                        </a>
                        <div className="quick-view">
                          <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                            <i className="ion-ios-search-strong" />
                          </a>
                        </div>
                      </div>
                      <ul className="product-flag">
                        <li className="new">New</li>
                      </ul>
                      <div className="product-decs">
                        <a className="inner-link" href="shop-4-column.html"><span>FACE</span></a>
                        <h2><Link to ="/Minimakeup"
                className="product-link">COMPACT FACE BRUSH</Link></h2>
                        <div className="rating-product">
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                          <i className="ion-android-star" />
                        </div>
                        <div className="pricing-meta">
                          <ul>
                            <li className="old-price not-cut">€18.90</li>
                          </ul>
                        </div>
                      </div>
                      <div className="add-to-link">
                        <ul>
                          <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                          <li>
                          <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                          </li>
                          <li>
                          <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                          </li>
                        </ul>
                      </div>
                    </article>
                  </div>
                </div>
              </div>
              {/* Tab One End */}
             </div>
            {/* Shop Tab Content End */}
              </div>
          {/* Shop Bottom Area End */}
        </div>
      </div>
    </div>
  </div>
  {/* Shop Category Area End */}
</div>

            </div>
        )
    }
}
export default Shopcos;