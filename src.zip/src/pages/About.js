import React from 'react';
import { Link } from 'react-router-dom';

class About extends React.Component {
    render() {
        return (
            <div>
                {/* Breadcrumb Area start */}
                <section className="breadcrumb-area">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="breadcrumb-content">
                                    <h1 className="breadcrumb-hrading">About Page</h1>
                                    <ul className="breadcrumb-links">
                                        <li><a href="index.html">Home</a></li>
                                        <li>About</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                {/* Breadcrumb Area End */}
                {/* About Area Start */}
                <section className="about-area">
                    <div className="container container-2">
                        <div className="row">
                            <div className="col-lg-6 mb-res-sm-50px">
                                <div className="about-left-image">
                                    <img src="assets/images/feature-bg/1.jpg" alt className="img-responsive" />
                                </div>
                            </div>
                            <div className="col-lg-6">
                                <div className="about-content">
                                    <div className="about-title">
                                        <h2>Welcome To Ecolife</h2>
                                    </div>
                                    <p className="mb-30px">
                                        We at Ecolife are really glad to see you all shop at our website.This is one stop shop where in you find all the neccessary items for your living.We have a wide range of collection ranging from organics to cosmatics to furniture ,electronics and medical all at your finger tip.
                                    </p>
                                    <p>
                                        We have made our website very easy for anyone to browse and shop.We aim at making our customers feel comfortable and have added the pay your way feature.We accept cash ,card and netbanking.Home delivery charges are free if you purchase items above Rs 1500.We have a variety of offers on products only for you.
                                    </p><p>Hoping you will have a great time here</p>
                                    <p />
                                </div>
                            </div>
                        </div>
                        <div className="row mt-60px">
                            <div className="col-md-4 mb-res-sm-30px">
                                <div className="single-about">
                                    <h4>Our Company</h4>
                                    <p>
                                        We as a team are really happy to welcome you all and hope you have an amazing time shopping here
                                    </p>
                                </div>
                            </div>
                            <div className="col-md-4 mb-res-sm-30px">
                                <div className="single-about">
                                    <h4>Customer review</h4>
                                    <p>Its very easy to use.And home delivery is also very fast.They also have amazing offers.
                                    </p>
                                </div>
                            </div>
                            <div className="col-md-4">
                                <div className="single-about">
                                    <h4>Testimonial</h4>
                                    <p>
                                        Amazing experience.All over happy to come across this website.Thank you.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                {/* About Area End */}
            </div>

        );
    }
}

export default About;