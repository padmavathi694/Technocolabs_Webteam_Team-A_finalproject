import react from 'react';
class Customer1 extends react.Component{
    render(){
        return(
       <div>
<div>
  
  <div className="container">
    <div className="row">
      <div className="col-md-12">
        <div className="breadcrumb-content">
          <center><h1 className="breadcrumb-hrading">Blog Post</h1>
         <ul className="breadcrumb-links">
            <li><a href="index.html">Home</a></li>
            <li>Single Blog Left Sidebar</li>
          </ul></center> 
        </div>
      </div>
    </div>
  </div>
  {/* Breadcrumb Area End */}
  {/* Shop Category Area End */}
  <div className="shop-category-area single-blog">
    <div className="container">
      <div className="row">
        <div className="col-lg-9 order-lg-last col-md-12 order-md-first">
          <div className="blog-posts">
            <div className="single-blog-post blog-grid-post">
              <div className="blog-post-media">
                <div className="blog-image single-blog">
                  <a href="#"><img src="assets/images/blog-image/blog-1.jpg" alt="blog" /></a>
                </div>
              </div>
              <div className="blog-post-content-inner">
                <h4 className="blog-title"><a href="#">Ecolife a great b2b website</a></h4>
                <ul className="blog-page-meta">
                  <li>
                    <a href="#"><i className="ion-person" /> Rahul</a>
                  </li>
                  <li>
                    <a href="#"><i className="ion-calendar" /> 24 April, 2020</a>
                  </li>
                </ul>
                <p>
                  After purchasing from the Ecolife said their service is fast, professional and customer-centric. The products are genuine, trustworthy and had a wonderful shopping experience. Customers seemed particularly pleased with the hassle-free cashback processing. Where one of the customers has praised saying now the shopping has become easier and cheaper while purchasing through Top cashback in One of them has even described Top cashback as one of the best Cashback sites.
                </p>
              </div>
              <div className="single-post-content">
                <p className="quate-speech">
                  I have been a part of Ecolife since 5 years and till date no product has come bad.
                </p>
                <p>
                  ecolife is best for in all products. They sell in best offers for products and also deliver in rural areas Flipkart always sell original brands and company products in best offers. So I recommend to my friend and families buy on ecolife. Best is kitchen items and decorative is more on ecolife that's the beauty.Thank you.Then one thing is suitable for every families.
                </p>
                <p>
                  Very good online e commerce website. Need not to worry about purchase quality and fast delivery.It is supper and esay to order and delivery option also good .i love it .one of the best .it has good product and it was awesome.
                </p>
              </div>
            </div>
            {/* single blog post */}
          </div>
          <div className="blog-single-tags-share d-sm-flex justify-content-between">
            <div className="blog-single-tags d-flex">
              <span className="title">Tags: </span>
              <ul className="tag-list">
                <li><a href="#">Fashion,</a></li>
                <li><a href="#">T-shirt,</a></li>
                <li><a href="#">White</a></li>
              </ul>
            </div>
            <div className="blog-single-share d-flex">
              <span className="title">Share:</span>
              <ul className="social">
                <li>
                  <a href="#"><i className="ion-social-facebook" /></a>
                </li>
                <li>
                  <a href="#"><i className="ion-social-twitter" /></a>
                </li>
                <li>
                  <a href="#"><i className="ion-social-google" /></a>
                </li>
                <li>
                  <a href="#"><i className="ion-social-instagram" /></a>
                </li>
              </ul>
            </div>
          </div>
          <div className="blog-related-post">
            <div className="row">
              <div className="col-md-12 text-center">
                {/* Section Title */}
                <div className="section-title underline-shape">
                  <h2>Related Post</h2>
                </div>
                {/* Section Title */}
              </div>
            </div>
            <div className="row">
              <div className="col-md-4 mb-res-md-30px mb-res-sm-30px">
                <div className="blog-post-media">
                  <div className="blog-image single-blog">
                    <a href="#"><img src="assets/images/blog-image/blog-1.jpg" alt="blog" /></a>
                  </div>
                </div>
                <div className="blog-post-content-inner">
                  <h4 className="blog-title"><a href="blog-single-left-sidebar.html">SALE on Diary products.</a></h4>
                  <ul className="blog-page-meta">
                  </ul>
                </div>
              </div>
              <div className="col-md-4 mb-res-md-30px mb-res-sm-30px">
                <div className="blog-post-media">
                  <div className="blog-image single-blog">
                    <a href="#"><img src="assets/images/blog-image/blog-2.jpg" alt="blog" /></a>
                  </div>
                </div>
                <div className="blog-post-content-inner">
                  <h4 className="blog-title"><a href="blog-single-left-sidebar.html">50% off on Home foods!</a></h4>
                  <ul className="blog-page-meta">
                  </ul>
                </div>
              </div>
              <div className="col-md-4">
                <div className="blog-post-media">
                  <div className="blog-image single-blog">
                    <a href="#"><img src="assets/images/blog-image/blog-3.jpg" alt="blog" /></a>
                  </div>
                </div>
                <div className="blog-post-content-inner">
                  <h4 className="blog-title"><a href="blog-single-left-sidebar.html">SALE ON organic veggies!</a></h4>
                  <ul className="blog-page-meta">
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="comment-area">
            <h2 className="comment-heading">3 Comments</h2>
            <div className="review-wrapper">
              <div className="single-review">
                <div className="review-img">
                  <img src="assets/images/testimonial-image/1.png" alt />
                </div>
                <div className="review-content">
                  <div className="review-top-wrap">
                    <div className="review-left">
                      <div className="review-name">
                        <h4>White Lewis</h4>
                        <span className="date">February 16, 2020 at 1:38 am</span>
                      </div>
                    </div>
                    <div className="review-left">
                      <a href="#">Reply</a>
                    </div>
                  </div>
                  <div className="review-bottom">
                    <p>
                      EXCELLENT.
                    </p>
                  </div>
                </div>
              </div>
              <div className="single-review child-review">
                <div className="review-img">
                  <img src="assets/images/testimonial-image/2.png" alt />
                </div>
                <div className="review-content">
                  <div className="review-top-wrap">
                    <div className="review-left">
                      <div className="review-name">
                        <h4>JENNY</h4>
                        <span className="date">February 16, 2020 at 1:38 am</span>
                      </div>
                    </div>
                    <div className="review-left">
                      <a href="#">Reply</a>
                    </div>
                  </div>
                  <div className="review-bottom">
                    <p>AWESOME.</p>
                  </div>
                </div>
              </div>
              <div className="single-review">
                <div className="review-img">
                  <img src="assets/images/testimonial-image/1.png" alt />
                </div>
                <div className="review-content">
                  <div className="review-top-wrap">
                    <div className="review-left">
                      <div className="review-name">
                        <h4>White Lewis</h4>
                        <span className="date">February 16, 2020 at 1:38 am</span>
                      </div>
                    </div>
                    <div className="review-left">
                      <a href="#">Reply</a>
                    </div>
                  </div>
                  <div className="review-bottom">
                    <p>
                      I know right.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="blog-comment-form">
            <h2 className="comment-heading">Leave a Reply</h2>
            <p>Your email address will not be published. Required fields are marked *</p>
            <div className="row">
              <div className="col-md-12">
                <div className="single-form">
                  <label>Your Review:</label>
                  <textarea placeholder="Write a review" defaultValue={""} />
                </div>
              </div>
              <div className="col-md-4">
                <div className="single-form">
                  <label>Name:</label>
                  <input type="text" placeholder="Name" />
                </div>
              </div>
              <div className="col-md-4">
                <div className="single-form">
                  <label>Email:</label>
                  <input type="email" placeholder="Email" />
                </div>
              </div>
              <div className="col-md-4">
                <div className="single-form">
                  <label>Website:</label>
                  <input type="email" placeholder="Website" />
                </div>
              </div>
              <div className="col-md-12">
                <div className="single-form">
                  <input type="submit" defaultValue="Submit" />
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Sidebar Area Start */}
        <div className="col-lg-3 order-lg-first col-md-12 order-md-last mb-res-md-60px mb-res-sm-60px">
          <div className="left-sidebar">
            {/* Sidebar single item */}
            <div className="sidebar-widget">
              <div className="main-heading">
                <h2>Search</h2>
              </div>
              <div className="search-widget">
                <form action="#">
                  <input placeholder="Search entire store here ..." type="text" />
                  <button type="submit"><i className="ion-ios-search-strong" /></button>
                </form>
              </div>
            </div>
            {/* Sidebar single item */}
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Categories</h2>
              </div>
              <div className="category-post">
                <ul>
                  <li><a href="#">Dresses (20)</a></li>
                  <li><a href="#">Jackets &amp; Coats (9)</a></li>
                  <li><a href="#">Sweaters (5)</a></li>
                  <li><a href="#">Jeans (11)</a></li>
                  <li><a href="#">Blouses &amp; Shirts (3)</a></li>
                  <li><a href="#">Electronic Cigarettes (6)</a></li>
                  <li><a href="#">Bags &amp; Cases (4)</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Recent Post</h2>
              </div>
              <div className="recent-post-widget">
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-1.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is First Post For XipBlog </a></h5>
                    <span className="date">APRIL 24, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-2.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Secound Post For XipBlog </a></h5>
                    <span className="date">APRIL 25, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-3.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Third Post For XipBlog </a></h5>
                    <span className="date">APRIL 26, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side m-0px">
                    <a href="#"><img src="assets/images/blog-image/blog-4.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Fourth Post For XipBlog </a></h5>
                    <span className="date">APRIL 27, 2020</span>
                  </div>
                </div>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Tag</h2>
              </div>
              <div className="sidebar-widget-tag">
                <ul>
                  <li><a href="#">Fresh Fruit</a></li>
                  <li><a href="#"> Fresh Vegetables</a></li>
                  <li><a href="#">Fresh Salad</a></li>
                  <li><a href="#"> Butter &amp; Eggs</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
          </div>
        </div>
        {/* Sidebar Area End */}
      </div>
    </div>
  </div>
  {/* Shop Category Area End */}
</div>


</div>
       
      
       
       );


}
}
export default Customer1;
