import React from 'react';
import {Link} from 'react-router-dom';
  class Product1 extends React.Component{
  render(){
  return(
      <div>
<div>
  {/* Breadcrumb Area start */}
  <section className="breadcrumb-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="breadcrumb-content">
            <h1 className="breadcrumb-hrading">Blog Post</h1>
            <ul className="breadcrumb-links">
              <li><a href="index.html">Home</a></li>
              <li>Blog Grid Left Sidebar</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Area End */}
  {/* Shop Category Area End */}
  <div className="shop-category-area blog-grid">
    <div className="container">
      <div className="row">
        <div className="col-lg-9 order-lg-last col-md-12 order-md-first">
          <div className="blog-posts">
            <div className="row">
              <div className="col-md-6 mb-res-sm-30px">
                <div className="single-blog-post blog-grid-post">
                  <div className="blog-post-media">
                    <div className="blog-image">
                      <a href="#"><img src="assets/images/product-image/electronic/7.jpg" alt="blog" /></a>
                    </div>
                  </div>
                  <div className="blog-post-content-inner mt-30">
                    <h4 className="blog-title"><a href="#">Google Pixel: Inovating ideas.</a></h4>
                    <ul className="blog-page-meta">
                      <li>
                        <a href="#"><i className="ion-person" />Syed Qadir</a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-calendar" /> 24 April, 2020</a>
                      </li>
                    </ul>
                    <p>
                      Google devices are most helpful when they seamlessly assist you throughout the day—wherever you are. We call this ambient computing, and it drives our approach to how Pixel should adapt to your needs in real time.
                      For example, Adaptive Sound improves the sound quality of your phone speaker based on your surroundings. It uses the microphone to assess the acoustics near you, then adjusts the sound equalizer settings in certain apps. Bringing your Pixel from the bedroom to the bathroom while getting ready in the morning? Your audio will sound great wherever you are.Your Pixel can also now detect if you’re viewing a website or app in a different language and translate it using Google Lens. Just take a screenshot or swipe into App Overview, and tap the Lens chip to see the translation. For available Google Lens languages go to g.co/help/lens. 
                      And for a little more help between charges, there are new context-aware battery features. Additional improvements to Adaptive Battery for Pixel 5 and Pixel 4a (5G) can automatically save even more power if a user is likely to miss their next charge, keeping the device powered even longer. Adaptive Charging helps preserve battery health over time by dynamically controlling how quickly a Pixel device charges. Just plug in your phone in the evening, set an alarm and the Adaptive Charging will work its magic. 
                    </p>
                  </div>
                </div>
                {/* single blog post */}
              </div>
              <div className="col-md-6">
                <div className="single-blog-post blog-grid-post">
                  <div className="blog-post-media">
                    <div className="blog-gallery">
                      <div className="gallery-item">
                        <a href="#"><img src="assets/images/product-image/organic/product-1.jpg" alt="blog" /></a>
                      </div>
                      <div className="gallery-item">
                        <a href="#"><img src="assets/images/blog-image/blog-3.jpg" alt="blog" /></a>
                      </div>
                      <div className="gallery-item">
                        <a href="#"><img src="assets/images/blog-image/blog-4.jpg" alt="blog" /></a>
                      </div>
                    </div>
                  </div>
                  <div className="blog-post-content-inner mt-30">
                    <h4 className="blog-title"><a href="#">Alphonso: The king of Mangoes.</a></h4>
                    <ul className="blog-page-meta">
                      <li>
                        <a href="#"><i className="ion-person" /> Sharon</a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-calendar" /> 24 April, 2020</a>
                      </li>
                    </ul>
                    <p>
                      Alphonso Mango is a king of all kinds of mangoes variety available in the world. And alphonso is seasonal fruit available only in April &amp; May months. So all mango lovers waiting for doing booking or ordering such a good quality alphonso mangoes from authentic or GI certified farmers. Devgad Alphonso mangoes offer incredible flavor, good quality, and a yummy mouth-watering taste. No pesticides, culture, or ethylene are used to grow these mangoes. Unlike other mango species, Devgad Alphonso has no fiber content.
                      The shelf life of Alphonso Mangoes is quite long. Farmers do not use any chemicals to preserve Devgad Alphonso mangoes. We guarantee quality and provide Alphonso Mangoes chemical-free and carbide-free to our valued customers.
                      Alphonso Mangoes are excellent for making refreshing drinks, soft drinks, juices, and mocktails. After trying this mango once, people are willing to pay for one more because of its quality properties.
                      Undoubtedly, Devgad Alphonso Mangoes are the most beautiful mangoes in the world. They are available for 4 to 6 weeks. Therefore, you will have to rush to make sure you grab some.With its bright yellow skin, red markings, shiny and delicious pulp - the Alphonso is invaluable!
                    </p>
                  </div>
                </div>
                {/* single blog post */}
              </div>
              <div className="col-md-6">
                <div className="single-blog-post blog-grid-post mt-30">
                  <div className="blog-post-media">
                    <div className="blog-image">
                      <a href="#"><img src="assets/images/product-image/electronic/9.jpg" alt="blog" /></a>
                    </div>
                  </div>
                  <div className="blog-post-content-inner mt-30">
                    <h4 className="blog-title"><a href="#">Gopro Hero 9</a></h4>
                    <ul className="blog-page-meta">
                      <li>
                        <a href="#"><i className="ion-person" /> Rahul jain</a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-calendar" /> 24 April, 2020</a>
                      </li>
                    </ul>
                    <p>
                      This year GoPro’s tagline was #MoreEverything, and when you look at the specs on the HERO9 vs HERO8, it’s easy to see what they mean.If you’re interested, you can also check out our detailed HERO8 review from last year.
                      Here are some of the new and major features of the HERO 9 Black. I’ll go into more detail on some of them below.
                      New 20mp sensor
                      -5k 30FPS
                      -TimeWarp 3.0
                      -HyperSmooth 3.0 Image Stabilization
                      -New full-colour front display LCD screen
                      -SuperPhoto with Improved HDR
                      -4k at 60fps in wide and linear
                      -100mbps Bit Rate in 5k, 4k and 2.7k
                      -1080p at 240fps
                      -Horizon Levelling built-in
                      -Bigger battery life
                      -Night lapse video
                      -Schedule Capture
                      -Duration Capture
                      -Folding fingers (removing the need for a frame)
                      -1080p live streaming
                      -SuperView, Wide, Linear and Narrow digital lenses
                      -Quick video capture presets
                      -LiveBurst Mode
                      -RAW photos in all modes
                      -Waterproof to 10m
                      -GPS
                      -Voice activation
                      -USB C Charging
                      -Front-facing microphone with improved audio
                      -Removable lens cover
                      -Optional modular accessories such as Media Mod, Light Mod and Display Mod.
                    </p>
                  </div>
                </div>
                {/* single blog post */}
              </div>
              <div className="col-md-6">
                <div className="single-blog-post blog-grid-post mt-30">
                  <div className="blog-post-media">
                    <div className="blog-image">
                      <a href="#"><img src="assets/images/blog-image/blog-4.jpg" alt="blog" /></a>
                    </div>
                  </div>
                  <div className="blog-post-content-inner mt-30">
                    <h4 className="blog-title"><a href="#">Omega 3 fish oil</a></h4>
                    <ul className="blog-page-meta">
                      <li>
                        <a href="#"><i className="ion-person" /> syed</a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-calendar" /> 24 April, 2020</a>
                      </li>
                    </ul>
                    <p>
                      Omega-3 fatty acids play important roles in brain function, normal growth and development, and inflammation. Deficiencies have been linked to a variety of health problems, including cardiovascular disease, some cancers, mood disorders, arthritis, and more. But that doesn’t mean taking high doses translates to better health and disease prevention.
                      Fish oil supplements have been promoted as easy way to protect the heart, ease inflammation, improve mental health, and lengthen life. Such claims are one reason why Americans spend more than $1 billion a year on over-the-counter fish oil. And food companies are adding it to milk, yogurt, cereal, chocolate, cookies, juice, and hundreds of other foods.
                      But the evidence for improving heart health is mixed. In November 2018, a study reported in the New England Journal of Medicine found that omega-3 fatty acid supplements did nothing to reduce heart attacks, strokes, or deaths from heart disease in middle-age men and women without any known risk factors for heart disease. Earlier research reported in the same journal in 2013 also reported no benefit in people with risk factors for heart disease.
                    </p>
                  </div>
                </div>
                {/* single blog post */}
              </div>
            </div>
          </div>
          {/*  Pagination Area Start */}
          {/*  Pagination Area End */}
        </div>
        {/* Sidebar Area Start */}
        <div className="col-lg-3 order-lg-first col-md-12 order-md-last mb-res-md-60px mb-res-sm-60px">
          <div className="left-sidebar">
            {/* Sidebar single item */}
            <div className="sidebar-widget">
              <div className="main-heading">
                <h2>Search</h2>
              </div>
              <div className="search-widget">
                <form action="#">
                  <input placeholder="Search entire store here ..." type="text" />
                  <button type="submit"><i className="ion-ios-search-strong" /></button>
                </form>
              </div>
            </div>
            {/* Sidebar single item */}
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Categories</h2>
              </div>
              <div className="category-post">
                <ul>
                  <li><a href="#">Dresses (20)</a></li>
                  <li><a href="#">Jackets &amp; Coats (9)</a></li>
                  <li><a href="#">Sweaters (5)</a></li>
                  <li><a href="#">Jeans (11)</a></li>
                  <li><a href="#">Blouses &amp; Shirts (3)</a></li>
                  <li><a href="#">Electronic Cigarettes (6)</a></li>
                  <li><a href="#">Bags &amp; Cases (4)</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Recent Post</h2>
              </div>
              <div className="recent-post-widget">
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-1.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is First Post For XipBlog </a></h5>
                    <span className="date">APRIL 24, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-2.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Secound Post For XipBlog </a></h5>
                    <span className="date">APRIL 25, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-3.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Third Post For XipBlog </a></h5>
                    <span className="date">APRIL 26, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side m-0px">
                    <a href="#"><img src="assets/images/blog-image/blog-4.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Fourth Post For XipBlog </a></h5>
                    <span className="date">APRIL 27, 2020</span>
                  </div>
                </div>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Tag</h2>
              </div>
              <div className="sidebar-widget-tag">
                <ul>
                  <li><a href="#">Fresh Fruit</a></li>
                  <li><a href="#"> Fresh Vegetables</a></li>
                  <li><a href="#">Fresh Salad</a></li>
                  <li><a href="#"> Butter &amp; Eggs</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
          </div>
        </div>
        {/* Sidebar Area End */}
      </div>
    </div>
  </div>
  {/* Shop Category Area End */}
</div>

          </div>
  )
  }
}
export default Product1;