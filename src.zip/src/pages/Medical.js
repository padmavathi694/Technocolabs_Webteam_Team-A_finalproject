import react from 'react';
import React , {Component} from 'react';
import {Link} from 'react-router-dom';
class Medical extends react.Component{
    render(){
        return(
       <div>
 <div>
  {/* Slider Arae Start */}
  <div className="slider-area">
    <div className="container">
      <div className="slider-active-3 owl-carousel slider-hm8 owl-dot-style">
        {/* Slider Single Item Start */}
        <div className="slider-height-19 d-flex align-items-start justify-content-start bg-img" style={{backgroundImage: 'url(assets/images/slider-image/sample-38.jpg)'}}>
          <div className="slider-content-16 slider-content-18 slider-animated-1 text-left">
            <h1 className="animated">
              HAND SANITIZER<br />
              <strong>80% ALCOHOL</strong>
            </h1>
            <p className="animated">Available In 1 Or 5 Gallon Containers</p>
            <Link to="/shop-right-sidebar" className="shop-btn animated">SHOP NOW</Link>
          </div>
        </div>
        {/* Slider Single Item End */}
        {/* Slider Single Item Start */}
        <div className="slider-height-19 d-flex align-items-start justify-content-start bg-img" style={{backgroundImage: 'url(assets/images/slider-image/sample-39.jpg)'}}>
          <div className="slider-content-16 slider-content-18 slider-content-20 slider-animated-1 text-left">
            <h1 className="animated">
              BOOST YOUR <br />
              <strong>IMMUNE SYSTEM</strong>
            </h1>
            <p className="animated">Full Life Natural Supplement</p>
            <Link to="/shop-right-sidebar" className="shop-btn animated">SHOP NOW</Link>
          </div>
        </div>
      </div>
      {/* Slider Single Item End */}
    </div>
  </div>
  {/* Slider Arae End */}
  {/* Banner Area Start */}
  <div className="banner-3-area">
    <div className="container">
      <div className="row">
        <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12 mb-res-xs-30 mb-res-sm-30">
          <div className="banner-wrapper">
            <Link to="/shop-right-sidebar"><img src="assets/images/banner-image/48.jpg" alt /></Link>
          </div>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12 col-xs-12">
          <div className="banner-wrapper">
            <Link to="/shop-right-sidebar"><img src="assets/images/banner-image/49.jpg" alt /></Link>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Banner Area End */}
  {/* Category Tab Area Start */}
  <section className="category-tab-area mt-60px">
    <div className="container">
      {/* Nav tabs */}
      <ul className="nav nav-tabs mb-30px">
        <li className="nav-item">
          <Link to="/shop-right-sidebar" className="nav-link active" data-toggle="tab">Featured</Link>
        </li>
        <li className="nav-item">
          <Link to="/shop-right-sidebar" className="nav-link" data-toggle="tab" href="#onsale">OnSale</Link>
        </li>
        <li className="nav-item">
          <Link to="/shop-right-sidebar" className="nav-link" data-toggle="tab" href="#bestseller">Bestseller</Link>
        </li>
      </ul>
      {/* Tab panes */}
      <div className="tab-content">
        {/* 1st tab start */}
        <div id="feature" className="tab-pane active">
          {/* Best Sell Slider Carousel Start */}
          <div className="best-sell-slider-2 owl-carousel owl-nav-style owl-nav-style-5">
            {/* Single Item */}
            <div className="list-product-2 mb-0 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                <Link to="/shop-right-sidebar" class="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/1.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/1.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  < Link to="/shop-right-sidebar"  className="inner-link"><span>MEDICAL DEVICE</span></Link>
                  <h2><Link to="/single-product-oticon" className="product-link">Oticon..</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹18.90</li>
                      <li className="current-price">₹34.21</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/2.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/2.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span></span></a>
                  <h2><Link to="/single-product-oticon" className="product-link">Hyaluronic acid..</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹18.90</li>
                      <li className="current-price">₹15.12</li>
                      <li className="discount-price">-20%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/4.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/4.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  < Link to="/shop-right-sidebar" className="inner-link"><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-hemp-oil" className="product-link">Hemp Oil..</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/5.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/5.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>Oil</span></a>
                  <h2><Link to="/single-product-oticon" className="product-link">Omega 3...</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/6.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/6.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-oticon" className="product-link">Probiotic Forte...</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/7.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/7.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>TABLETS</span></Link>
                  <h2><Link to="/single-product-oticon" className="product-link">energy tablet...</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/8.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/8.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link"><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-oticon" className="product-link">Keto Advanced weight loss..</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/cart"> Add to cart</Link>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/9.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/9.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link"><span>MEDICAL DEVICE</span></Link>
                  <h2><Link to="/single-product-oticon" className="product-link">Thermometer...</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹29.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/10.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/10.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICAL MASKS</span></Link>
                  <h2><Link to="/single-product-oticon" className="product-link">MASKS.</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹23.90</li>
                      <li className="current-price">₹21.51</li>
                      <li className="discount-price">-10%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/3.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/3.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link"><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-oticon" className="product-link">whey protein blend..</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Single Item */}
          </div>
          {/* Best Sells Carousel End */}
        </div>
        {/* 1st tab end */}
        {/* 2nd tab start */}
        <div id="onsale" className="tab-pane fade">
          {/* Best Sell Slider Carousel Start */}
          <div className="best-sell-slider-2 owl-carousel owl-nav-style">
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/1.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/1.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link"><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">Juicy Couture Juicy Quilted Ter..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹18.90</li>
                      <li className="current-price">₹34.21</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/2.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/2.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">Hyaluronic acid...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹18.90</li>
                      <li className="current-price">₹15.12</li>
                      <li className="discount-price">-20%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/3.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/4.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link"><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">whey protein blend..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/5.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/5.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link"><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">Juicy Couture Tricot Logo Strip..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/6.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/6.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">Probiotic Forte...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/7.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/7.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>TABLETS</span></Link>
                  <h2><a href="single-product-energy-tablet.html" className="product-link">Energy tablet...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/8.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/8.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><a href="single-product-advanced-weight-loss.html" className="product-link">Keto advanced weight loss..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/1.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/1.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">New Luxury Men's Slim Fit Shi...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹29.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/2.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/2.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link"><span>MEDICAL DEVICE</span></Link>
                  <h2><Link to="/single-product-oticon" className="product-link">Oticon...</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />

                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹23.90</li>
                      <li className="current-price">₹21.51</li>
                      <li className="discount-price">-10%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/cart"> Add to cart</Link>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/3.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/3.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">whey protein blend..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/4.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/4.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">Madden by Steve Madden Cale 6</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹11.90</li>
                      <li className="current-price">₹10.12</li>
                      <li className="discount-price">-15%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/5.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/6.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">Juicy Couture Juicy Quilted Ter..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹35.90</li>
                      <li className="current-price">₹34.11</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
          </div>
          {/* Best Sells Carousel End */}
        </div>
        {/* 2nd tab end */}
        {/* 3rd tab start */}
        <div id="bestseller" className="tab-pane fade">
          {/* Best Sell Slider Carousel Start */}
          <div className="best-sell-slider-2 owl-carousel owl-nav-style">
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/1.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/1.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">Juicy Couture Juicy Quilted Ter..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹18.90</li>
                      <li className="current-price">₹34.21</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/2.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/2.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>MEDICINE</span></a>
                  <h2><Link to="/shop-right-sidebar" className="product-link">Hyaluronic acid....</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹18.90</li>
                      <li className="current-price">₹15.12</li>
                      <li className="discount-price">-20%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/3.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/4.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link"><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">whey protein blend..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/5.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/5.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>GRAPHIC CORNER</span></a>
                  <h2><a href="single-product.html" className="product-link">Juicy Couture Tricot Logo Strip..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/6.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/6.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product.html" className="product-link">Probiotic Forte...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/7.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/7.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>GRAPHIC CORNAR</span></a>
                  <h2><a href="single-product.html" className="product-link">energy tablet...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/8.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/8.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product-advanced-weight-loss.html" className="product-link">Keto Advanced weight loss..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/1.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/1.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product.html" className="product-link">New Luxury Men's Slim Fit Shi...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹29.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/2.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/2.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><Link to="/single-product-oticon" className="product-link">Oticon...</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹23.90</li>
                      <li className="current-price">₹21.51</li>
                      <li className="discount-price">-10%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/cart"> Add to cart</Link>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/3.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/3.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product.html" className="product-link">whey protein blend..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
            <div className="list-product-2 mb-0">
              <article className="list-product border-b-0">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/4.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/4.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product.html" className="product-link">Madden by Steve Madden Cale 6</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹11.90</li>
                      <li className="current-price">₹10.12</li>
                      <li className="discount-price">-15%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
              {/* Single Item */}
              <article className="list-product">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/5.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/6.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product.html" className="product-link">Juicy Couture Juicy Quilted Ter..</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹35.90</li>
                      <li className="current-price">₹34.11</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Single Item */}
          </div>
          {/* Best Sells Carousel End */}
        </div>
        {/* 3rd tab end */}
      </div>
    </div>
  </section>
  {/* Category Tab Area end */}
  {/* Banner Area 2 Start */}
  <div className="banner-area-2 mt-60px">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="banner-inner">
            <a href="shop-4-column.html"><img src="assets/images/banner-image/57.jpg" alt /></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Banner Area 2 End */}
  {/* Hot deal area Start */}
  <section className="hot-deal-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          {/* Section Title */}
          <div className="section-title">
            <h2>Vitamins &amp; Minerals</h2>
          </div>
          {/* Section Title End*/}
        </div>
      </div>
      <div className="banner-inner-area d-flex">
        <div className="banner-left">
          <div className="banner-wrapper">
            <Link to="/shop-right-sidebar"><img src="assets/images/banner-image/51.jpg" alt /></Link>
          </div>
        </div>
        {/* New Arrivals Area Start */}
        <div className="banner-right">
          {/* New Product Slider Start */}
          <div className="new-product-slider-2 owl-carousel owl-nav-style owl-nav-style-5">
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/16.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/16.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-hemp-oil" className="product-link">Mutli vitamins and  Mine..</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹23.90</li>
                      <li className="current-price">₹21.51</li>
                      <li className="discount-price">-10%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/13.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/13.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-hemp-oil" className="product-link">Apple Cider Vinegar..</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹29.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/12.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/12.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICAL MASKS</span></Link>
                  <h2><Link to="/single-product-hemp-oil" className="product-link">N95 Masks</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹105.90</li>
                      <li className="current-price">₹90.11</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/14.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/14.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-hemp-oil" className="product-link">Biotrients..</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹11.90</li>
                      <li className="current-price">₹10.12</li>
                      <li className="discount-price">-15%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/5.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/5.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">Water and Wind Resist...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹11.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/6.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/6.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link"><span>MEDICINE</span></Link>
                  <h2><a href="single-product.html" className="product-link">Juicy Couture Solid Slee...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/7.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/7.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product.html" className="product-link">Water and Wind Resist...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹11.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
          </div>
          {/* Product Slider End */}
        </div>
      </div>
    </div>
  </section>
  {/* Hot Deal Area End */}
  {/* Hot deal area Start */}
  <section className="hot-deal-area mt-30px">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          {/* Section Title */}
          <div className="section-title">
            <h2>Herbs &amp; Botanicals</h2>
          </div>
          {/* Section Title End*/}
        </div>
      </div>
      <div className="banner-inner-area d-flex">
        <div className="banner-left">
          <div className="banner-wrapper">
            <Link to="/shop-right-sidebar"><img src="assets/images/banner-image/56.jpg" alt /></Link>
          </div>
        </div>
        {/* New Arrivals Area Start */}
        <div className="banner-right">
          {/* New Product Slider Start */}
          <div className="new-product-slider-2 owl-carousel owl-nav-style owl-nav-style-5">
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <a href="single-product-pure-primimum-moringa.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/17.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/17.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-hemp-oil" className="product-link">pure primimum moringa</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹23.90</li>
                      <li className="current-price">₹21.51</li>
                      <li className="discount-price">-10%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/18.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/18.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-hemp-oil" className="product-link">Earthly Botanicals</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹29.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/19.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/19.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-hemp-oil" className="product-link">Anveya Vitamin C</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹35.90</li>
                      <li className="current-price">₹34.11</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/20.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/20.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <Link to="/Wishlist" className="quick_view"  title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </Link>
                    <Link to="/Compare" className="quick_view mlr-10px"  title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </Link>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <Link to="/shop-right-sidebar" className="inner-link" ><span>MEDICINE</span></Link>
                  <h2><Link to="/single-product-hemp-oil" className="product-link">Energy White Magic Spray</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">₹11.90</li>
                      <li className="current-price">₹10.12</li>
                      <li className="discount-price">-15%</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <Link to="/Cart"> Add to cart</Link>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <Link to="/shop-right-sidebar" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/5.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/5.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product.html" className="product-link">Water and Wind Resist...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹11.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/6.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/6.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product.html" className="product-link">Juicy Couture Solid Slee...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹18.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
            {/* Product Single Item */}
            <div className="product-inner-item">
              <article className="list-product mb-30px">
                <div className="img-block">
                  <a href="single-product.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/medical/7.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/medical/7.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="wishlist.html" title="Add to wishlist">
                      <i className="ion-android-favorite-outline" />
                    </a>
                    <a className="quick_view mlr-10px" href="compare.html" title="Add to compare">
                      <i className="ion-ios-shuffle-strong" />
                    </a>
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs text-center">
                  <a className="inner-link" href="shop-4-column.html"><span>STUDIO DESIGN</span></a>
                  <h2><a href="single-product.html" className="product-link">Water and Wind Resist...</a></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price not-cut">₹11.90</li>
                    </ul>
                  </div>
                </div>
                <div className="add-to-link-btn">
                  <a href="#"> Add to cart</a>
                </div>
              </article>
            </div>
          </div>
          {/* Product Slider End */}
        </div>
      </div>
    </div>
  </section>
  {/* Hot Deal Area End */}
</div>


</div>
      
       
        );


}
}
export default Medical;
