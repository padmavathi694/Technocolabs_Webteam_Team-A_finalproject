
  import React from 'react';
  import {Link} from 'react-router-dom';
  class Organic extends React.Component{
  render(){
  return(
  <div>
        {/* Slider Arae Start */}
    <div className="slider-area">
      <div className="slider-active-3 owl-carousel slider-hm8 owl-dot-style">
        {/* Slider Single Item Start */}
        <div className="slider-height-6 d-flex align-items-start justify-content-start bg-img" style={{backgroundImage: 'url(assets/images/slider-image/sample-1.jpg)'}}>
          <div className="container">
            <div className="slider-content-1 slider-animated-1 text-left">
              <span className="animated">NOT FRIED NOT BAKED</span>
              <h1 className="animated">
                Freeze Dried Fruits <br />
                Pineapple Coconut
              </h1>
              <p className="animated">Free Shipping On Qualified Orders Over $35</p>
              < Link to ="/Shop"className="shop-btn animated">SHOP NOW</Link>
            </div>
          </div>
        </div>
        {/* Slider Single Item End */}
        {/* Slider Single Item Start */}
        <div className="slider-height-6 d-flex align-items-start justify-content-start bg-img" style={{backgroundImage: 'url(assets/images/slider-image/sample-2.jpg)'}}>
          <div className="container">
            <div className="slider-content-1 slider-animated-1 text-left">
              <span className="animated">100% NATURAL</span>
              <h1 className="animated">
                Organic Fruits <br />
                Summer Drinks
              </h1>
              <p className="animated">fresh New pack Brusting Fruits</p>
              <Link to ="/Shop" className="shop-btn animated">SHOP NOW</Link>
            </div>
          </div>
        </div>
        {/* Slider Single Item End */}
      </div>
    </div>
    {/* Slider Arae End */}
    {/* Static Area Start */}
    <section className="static-area mtb-60px">
      <div className="container">
        <div className="static-area-wrap">
          <div className="row">
            {/* Static Single Item Start */}
            <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
              <div className="single-static pb-res-md-0 pb-res-sm-0 pb-res-xs-0">
                <img src="assets/images/icons/static-icons-1.png" alt className="img-responsive" />
                <div className="single-static-meta">
                  <h4>Free Shipping</h4>
                  <p>On all orders over $75.00</p>
                </div>
              </div>
            </div>
            {/* Static Single Item End */}
            {/* Static Single Item Start */}
            <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
              <div className="single-static pb-res-md-0 pb-res-sm-0 pb-res-xs-0 pt-res-xs-20">
                <img src="assets/images/icons/static-icons-2.png" alt className="img-responsive" />
                <div className="single-static-meta">
                  <h4>Free Returns</h4>
                  <p>Returns are free within 9 days</p>
                </div>
              </div>
            </div>
            {/* Static Single Item End */}
            {/* Static Single Item Start */}
            <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
              <div className="single-static pt-res-md-30 pb-res-sm-30 pb-res-xs-0 pt-res-xs-20">
                <img src="assets/images/icons/static-icons-3.png" alt className="img-responsive" />
                <div className="single-static-meta">
                  <h4>100% Payment Secure</h4>
                  <p>Your payment are safe with us.</p>
                </div>
              </div>
            </div>
            {/* Static Single Item End */}
            {/* Static Single Item Start */}
            <div className="col-lg-3 col-xs-12 col-md-6 col-sm-6">
              <div className="single-static pt-res-md-30 pb-res-sm-30 pt-res-xs-20">
                <img src="assets/images/icons/static-icons-4.png" alt className="img-responsive" />
                <div className="single-static-meta">
                  <h4>Support 24/7</h4>
                  <p>Contact us 24 hours a day</p>
                </div>
              </div>
            </div>
            {/* Static Single Item End */}
          </div>
        </div>
      </div>
    </section>
    {/* Static Area End */}
    {/* Best Sells Area Start */}
    <section className="best-sells-area mb-30px">
      <div className="container">
        {/* Section Title Start */}
        <div className="row">
          <div className="col-md-12">
            <div className="section-title">
              <h2>Best Sellers</h2>
              <p>ECOLIFE'S BEST SELLING ITEMS</p>
            </div>
          </div>
        </div>
        {/* Section Title End */}
        {/* Best Sell Slider Carousel Start */}
        <div className="best-sell-slider owl-carousel owl-nav-style">
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
            <Link to ="/Shop" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-1.jpg" alt />
              </Link>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
              <h2>< Link to ="/Mangoes" className="product-link">FRESH JUICY MANGO</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€18.90</li>
                  <li className="current-price">€34.21</li>
                  <li className="discount-price">-5%</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart" className="cart-btn"  >ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
                  <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
              <Link to ="/Shop" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-2.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-15.jpg" alt />
              </Link>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>NATURALS</span></a>
              <h2>< Link to ="/Shop"  className="product-link">MANGO FRUIT JUICE</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€18.90</li>
                  <li className="current-price">€15.12</li>
                  <li className="discount-price">-20%</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
                  <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
            <Link to ="/Shop" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-3.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-4.jpg" alt />
              </Link>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>FRESHO SIGNATURE</span></a>
              <h2><Link to ="/Almonds"className="product-link">CALIFORNIA ALMONDS</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€18.90</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
                  <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
              <a href="single-product.html" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-5.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-5.jpg" alt />
              </a>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>FRESHO SIGNATURE</span></a>
              <h2><Link to ="/Shop" className="product-link">DRY FRUITS</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€18.90</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart"  className="cart-btn" >ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
                  <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
            <Link to ="/Shop" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-6.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-6.jpg" alt />
              </Link>
              <div className="quick-view">
                <a className="quick_vi
                              ew" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
              <h2><Link to ="/Strawberry" className="product-link">FRESH STRAWBERRIES</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€18.90</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart" className="cart-btn">ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
                  <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
        </div>
        {/* Best Sells Carousel End */}
      </div>
    </section>
    {/* Best Sells Slider End */}
    {/* Category Area Start */}
    <section className="categorie-area">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            {/* Section Title */}
            <div className="section-title mt-res-sx-30px mt-res-md-30px">
              <h2>Popular Categories</h2>
              <p>CHECK OUT ECOLIFE'S POPULAR CATEGORIES NOW!!!!</p>
            </div>
            {/* Section Title */}
          </div>
        </div>
        {/* Category Slider Start */}
        <div className="category-slider owl-carousel owl-nav-style">
          {/* Single item */}
          <div className="category-item">
            <div className="category-list mb-30px">
              <div className="category-thumb">
              <Link to ="/Shop">
                  <img src="assets/images/product-image/organic/thumb-1.jpg" alt />
                </Link>
              </div>
              <div className="desc-listcategoreis">
                <div className="name_categories">
                  <h4>Fresh Vegetables</h4>
                </div>
                <span className="number_product">17 Products</span>
                <Link to ="/Shop" Shop Now ><i className="ion-android-arrow-dropright-circle" /></Link>
              </div>
            </div>
            <div className="category-list">
              <div className="category-thumb">
              <Link to ="/Shop">
                  <img src="assets/images/product-image/organic/thumb-2.jpg" alt />
                </Link>
              </div>
              <div className="desc-listcategoreis">
                <div className="name_categories">
                  <h4>Fresh Salad &amp; Dips</h4>
                </div>
                <span className="number_product">17 Products</span>
                <Link to ="/Shop"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
              </div>
            </div>
          </div>
          {/* Single item */}
          <div className="category-item">
            <div className="category-list mb-30px">
              <div className="category-thumb">
              <Link to ="/Shop">
                  <img src="assets/images/product-image/organic/thumb-3.jpg" alt />
                </Link>
              </div>
              <div className="desc-listcategoreis">
                <div className="name_categories">
                  <h4>Fresh Fruit</h4>
                </div>
                <span className="number_product">17 Products</span>
                <Link to ="/Shop">Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
              </div>
            </div>
            <div className="category-list">
              <div className="category-thumb">
              <Link to ="/Shop">
                  <img src="assets/images/product-image/organic/thumb-4.jpg" alt />
                </Link>
              </div>
              <div className="desc-listcategoreis">
                <div className="name_categories">
                  <h4>Baking &amp; Cooking</h4>
                </div>
                <span className="number_product">17 Products</span>
                <Link to ="/Shop"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
              </div>
            </div>
          </div>
          {/* Single item */}
          <div className="category-item">
            <div className="category-list mb-30px">
              <div className="category-thumb">
              <Link to ="/Shop">
                  <img src="assets/images/product-image/organic/thumb-5.jpg" alt />
                </Link>
              </div>
              <div className="desc-listcategoreis">
                <div className="name_categories">
                  <h4>Fresh Cream &amp; Custard</h4>
                </div>
                <span className="number_product">17 Products</span>
                <Link to ="/Shop"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
              </div>
            </div>
            <div className="category-list">
              <div className="category-thumb">
              <Link to ="/Shop">
                  <img src="assets/images/product-image/organic/thumb-6.jpg" alt />
                </Link>
              </div>
              <div className="desc-listcategoreis">
                <div className="name_categories">
                  <h4>Milk, Butter &amp; Eggs</h4>
                </div>
                <span className="number_product">17 Products</span>
                <Link to ="/Shop"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
              </div>
            </div>
          </div>
          {/* Single item */}
          <div className="category-item">
            <div className="category-list mb-30px">
              <div className="category-thumb">
              <Link to ="/Shop">
                  <img src="assets/images/product-image/organic/thumb-7.jpg" alt />
                </Link>
              </div>
              <div className="desc-listcategoreis">
                <div className="name_categories">
                  <h4>Spreads &amp; Margarine</h4>
                </div>
                <span className="number_product">17 Products</span>
                <Link to ="/Shop"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
              </div>
            </div>
            <div className="category-list">
              <div className="category-thumb">
              <Link to ="/Shop">
                  <img src="assets/images/product-image/organic/thumb-8.jpg" alt />
                </Link>
              </div>
              <div className="desc-listcategoreis">
                <div className="name_categories">
                  <h4>Fresh Vegetables</h4>
                </div>
                <span className="number_product">17 Products</span>
                <Link to ="/Shop"> Shop Now <i className="ion-android-arrow-dropright-circle" /></Link>
              </div>
            </div>
          </div>
          {/* Single item */}
        </div>
      </div>
    </section>
    {/* Category Area End  */}
    {/* Hot deal area Start */}
    <section className="hot-deal-area">
      <div className="container">
        <div className="row">
          <div className="col-xs-12 col-sm-12 col-md-5 col-lg-5 col-xl-4">
            <div className="row">
              <div className="col-md-12">
                {/* Section Title */}
                <div className="section-title">
                  <h2>Hot Deals</h2>
                  <p>ECOLIFE'S HOT DEALS ONLY FOR YOU</p>
                </div>
                {/* Section Title End*/}
              </div>
            </div>
            {/* Hot Deal Slider Start */}
            <div className="hot-deal owl-carousel owl-nav-style">
              {/*  Single item */}
              <article className="list-product">
                <div className="img-block">
                <Link to ="/Mangoes"className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                  <h2><Link to ="/Mangoes" className="product-link">YUMMY MANGOES</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">€18.90</li>
                      <li className="current-price">€34.21</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="in-stock">Availability: <span>50 In Stock</span></div>
                <div className="clockdiv">
                  <div className="title_countdown">Hurry Up! Offers ends in:</div>
                  <div data-countdown="2021/06/14" />
                </div>
              </article>
              {/*  Single item */}
              <article className="list-product">
                <div className="img-block">
                <Link to ="/Tadka" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/organic/product-11.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/organic/product-12.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" Link to ="/Shop"><span>HALDIRAM'S</span></a>
                  <h2><Link to ="/Tadka" className="product-link">PUNJABI TADKA</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">€18.90</li>
                      <li className="current-price">€34.21</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="in-stock">Availability: <span>70 In Stock</span></div>
                <div className="clockdiv">
                  <div className="title_countdown">Hurry Up! Offers ends in:</div>
                  <div data-countdown="2021/06/15" />
                </div>
              </article>
              {/*  Single item */}
              <article className="list-product">
                <div className="img-block">
                  <a href="single-product-pomgranade juice.html" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/organic/product-22.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/organic/product-22.jpg" alt />
                  </a>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" Link to ="/Shop"><span>JUICE</span></a>
                  <h2>< Link to ="/Pomogranade" className="product-link">POMGRANATE JUICE</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">€18.90</li>
                      <li className="current-price">€34.21</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="in-stock">Availability: <span>9 In Stock</span></div>
                <div className="clockdiv">
                  <div className="title_countdown">Hurry Up! Offers ends in:</div>
                  <div data-countdown="2021/06/16" />
                </div>
              </article>
              {/*  Single item */}
              <article className="list-product">
                <div className="img-block">
                <Link to ="/Strawberry" className="thumbnail">
                    <img className="first-img" src="assets/images/product-image/organic/product-6.jpg" alt />
                    <img className="second-img" src="assets/images/product-image/organic/product-6.jpg" alt />
                  </Link>
                  <div className="quick-view">
                    <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                      <i className="ion-ios-search-strong" />
                    </a>
                  </div>
                </div>
                <ul className="product-flag">
                  <li className="new">New</li>
                </ul>
                <div className="product-decs">
                  <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                  <h2><Link to ="/Strawberry" className="product-link">STRAWBERRIES</Link></h2>
                  <div className="rating-product">
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                    <i className="ion-android-star" />
                  </div>
                  <div className="pricing-meta">
                    <ul>
                      <li className="old-price">€18.90</li>
                      <li className="current-price">€34.21</li>
                      <li className="discount-price">-5%</li>
                    </ul>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="in-stock">Availability: <span>19 In Stock</span></div>
                <div className="clockdiv">
                  <div className="title_countdown">Hurry Up! Offers ends in:</div>
                  <div data-countdown="2021/06/14" />
                </div>
              </article>
              {/*  Single item */}
            </div>
            {/* Hot Deal Slider End */}
          </div>
          {/* New Arrivals Area Start */}
          <div className="col-xs-12 col-sm-12 col-md-7 col-lg-7 col-xl-8">
            <div className="row">
              <div className="col-md-12">
                {/* Section Title */}
                <div className="section-title ml-0px mt-res-sx-30px">
                  <h2>New Arrivals</h2>
                  <p>CHECK OUT NOW-OUR NEW ARRIVALS!!</p>
                </div>
                {/* Section Title */}
              </div>
            </div>
            {/* New Product Slider Start */}
            <div className="new-product-slider owl-carousel owl-nav-style">
              {/* Product Single Item */}
              <div className="product-inner-item">
                <article className="list-product mb-30px">
                  <div className="img-block">
                    <Link to ="/Shop" className="thumbnail">
                      <img className="first-img" src="assets/images/product-image/organic/product-16.jpg" alt />
                      <img className="second-img" src="assets/images/product-image/organic/product-16.jpg" alt />
                    </Link>
                    <div className="quick-view">
                      <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                        <i className="ion-ios-search-strong" />
                      </a>
                    </div>
                  </div>
                  <ul className="product-flag">
                    <li className="new">New</li>
                  </ul>
                  <div className="product-decs">
                    <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                    <h2><Link to ="/Shop" className="product-link">TILAPIA FISH FILLET</Link></h2>
                    <div className="rating-product">
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                    </div>
                    <div className="pricing-meta">
                      <ul>
                        <li className="old-price">€23.90</li>
                        <li className="current-price">€21.51</li>
                        <li className="discount-price">-10%</li>
                      </ul>
                    </div>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </article>
                <article className="list-product">
                  <div className="img-block">
                  <Link to ="/Shop" className="thumbnail">
                      <img className="first-img" src="assets/images/product-image/organic/product-15.jpg" alt />
                      <img className="second-img" src="assets/images/product-image/organic/product-2.jpg" alt />
                    </Link>
                    <div className="quick-view">
                      <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                        <i className="ion-ios-search-strong" />
                      </a>
                    </div>
                  </div>
                  <ul className="product-flag">
                    <li className="new">New</li>
                  </ul>
                  <div className="product-decs">
                    <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                    <h2><Link to ="/Shop" className="product-link">FRUIT JUICE</Link></h2>
                    <div className="rating-product">
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                    </div>
                    <div className="pricing-meta">
                      <ul>
                        <li className="old-price">€35.90</li>
                        <li className="current-price">€34.11</li>
                        <li className="discount-price">-5%</li>
                      </ul>
                    </div>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><a className="cart-btn" Link to ="/Cart">ADD TO CART </a></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </article>
              </div>
              {/* Product Single Item */}
              <div className="product-inner-item">
                <article className="list-product mb-30px">
                  <div className="img-block">
                  <Link to ="/Shop" className="thumbnail">
                      <img className="first-img" src="assets/images/product-image/organic/product-4.jpg" alt />
                      <img className="second-img" src="assets/images/product-image/organic/product-13.jpg" alt />
                    </Link>
                    <div className="quick-view">
                      <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                        <i className="ion-ios-search-strong" />
                      </a>
                    </div>
                  </div>
                  <ul className="product-flag">
                    <li className="new">New</li>
                  </ul>
                  <div className="product-decs">
                    <a className="inner-link" Link to ="/Shop"><span>CHIPS</span></a>
                    <h2><Link to ="/Shop" className="product-link">ALL TIME TASTY-ROUGH CUTS</Link></h2>
                    <div className="rating-product">
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                    </div>
                    <div className="pricing-meta">
                      <ul>
                        <li className="old-price not-cut">€29.90</li>
                      </ul>
                    </div>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </article>
                <article className="list-product">
                  <div className="img-block">
                  <Link to ="/Shop" className="thumbnail">
                      <img className="first-img" src="assets/images/product-image/organic/product-10.jpg" alt />
                      <img className="second-img" src="assets/images/product-image/organic/product-10.jpg" alt />
                    </Link>
                    <div className="quick-view">
                      <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                        <i className="ion-ios-search-strong" />
                      </a>
                    </div>
                  </div>
                  <ul className="product-flag">
                    <li className="new">New</li>
                  </ul>
                  <div className="product-decs">
                    <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                    <h2><Link to ="/Shop" className="product-link">FARM PICKED-ORANGES</Link></h2>
                    <div className="rating-product">
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                    </div>
                    <div className="pricing-meta">
                      <ul>
                        <li className="old-price not-cut">€29.90</li>
                      </ul>
                    </div>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </article>
              </div>
              {/* Product Single Item */}
              <div className="product-inner-item">
                <article className="list-product mb-30px">
                  <div className="img-block">
                  <Link to ="/Shop" className="thumbnail">
                      <img className="first-img" src="assets/images/product-image/organic/product-11.jpg" alt />
                      <img className="second-img" src="assets/images/product-image/organic/product-12.jpg" alt />
                    </Link>
                    <div className="quick-view">
                      <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                        <i className="ion-ios-search-strong" />
                      </a>
                    </div>
                  </div>
                  <ul className="product-flag">
                    <li className="new">New</li>
                  </ul>
                  <div className="product-decs">
                    <a className="inner-link" Link to ="/Shop"><span>NAMKEEN</span></a>
                    <h2><Link to ="/Tadka" className="product-link">PUNJABI TADKA</Link></h2>
                    <div className="rating-product">
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                    </div>
                    <div className="pricing-meta">
                      <ul>
                        <li className="old-price">€35.90</li>
                        <li className="current-price">€34.11</li>
                        <li className="discount-price">-5%</li>
                      </ul>
                    </div>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </article>
                <article className="list-product">
                  <div className="img-block">
                  <Link to ="/Shop" className="thumbnail">
                      <img className="first-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                      <img className="second-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                    </Link>
                    <div className="quick-view">
                      <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                        <i className="ion-ios-search-strong" />
                      </a>
                    </div>
                  </div>
                  <ul className="product-flag">
                    <li className="new">New</li>
                  </ul>
                  <div className="product-decs">
                    <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                    <h2><Link to ="/Mangoes" className="product-link">FRESH MANGOES</Link></h2>
                    <div className="rating-product">
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                      <i className="ion-android-star" />
                    </div>
                    <div className="pricing-meta">
                      <ul>
                        <li className="old-price">€35.90</li>
                        <li className="current-price">€34.11</li>
                        <li className="discount-price">-5%</li>
                      </ul>
                    </div>
                  </div>
                  <div className="add-to-link">
                    <ul>
                      <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                      <li>
                        <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                      </li>
                      <li>
                        <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                      </li>
                    </ul>
                  </div>
                </article>
              </div>
            </div>
          </div>
        </div>
      </div></section>
    {/* Hot Deal Area End */}
    {/* Banner Area Start */}
    <div className="banner-area">
      <div className="container">
        <div className="row">
          <div className="col-md-3 col-xs-12">
            <div className="banner-wrapper">
            <Link to ="/Shop"><img src="assets/images/banner-image/1.jpg" alt /></Link>
            </div>
          </div>
          <div className="col-md-6 col-xs-12 mt-res-sx-30px">
            <div className="banner-wrapper">
            <Link to ="/Shop"><img src="assets/images/banner-image/2.jpg" alt /></Link>
            </div>
          </div>
          <div className="col-md-3 col-xs-12 mt-res-sx-30px">
            <div className="banner-wrapper">
            <Link to ="/Shop"><img src="assets/images/banner-image/3.jpg" alt /></Link>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Banner Area End */}
    {/* Feature Area Start */}
    <section className="feature-area">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            {/* Section Title */}
            <div className="section-title">
              <h2>Featured Products</h2>
              <p>ECOLIFES'S FEATURE PRODUCTS</p>
            </div>
            {/* Section Title */}
          </div>
        </div>
        {/* Feature Slider Start */}
        <div className="feature-slider owl-carousel owl-nav-style">
          {/* Single Item */}
          <div className="feature-slider-item">
            <article className="list-product">
              <div className="img-block">
              <Link to ="/Shop" className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/organic/product-18.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/organic/product-18.jpg" alt />
                </Link>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <div className="product-decs">
                <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                <h2><Link to ="/Shop" className="product-link">JUICY TOMATOES</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price not-cut">€29.90</li>
                  </ul>
                </div>
              </div>
            </article>
            <article className="list-product">
              <div className="img-block">
              <Link to ="/Shop" className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/organic/product-19.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/organic/product-20.jpg" alt />
                </Link>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <div className="product-decs">
                <a className="inner-link" Link to ="/Shop"><span>NUTS</span></a>
                <h2><Link to ="/Shop" className="product-link">MIXED NUTS</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price not-cut">€29.90</li>
                  </ul>
                </div>
              </div>
            </article>
          </div>
          {/* Single Item */}
          <div className="feature-slider-item">
            <article className="list-product">
              <div className="img-block">
              <Link to ="/Shop" className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/organic/product-16.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/organic/product-17.jpg" alt />
                </Link>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <div className="product-decs">
                <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                <h2><Link to ="/Shop" className="product-link">THALPIA FISH FILLETS</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price">€23.90</li>
                    <li className="current-price">€21.51</li>
                  </ul>
                </div>
              </div>
            </article>
            <article className="list-product">
              <div className="img-block">
              <Link to ="/Shop" className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/organic/product-11.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/organic/product-12.jpg" alt />
                </Link>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <div className="product-decs">
                <a className="inner-link" Link to ="/Shop"><span>NAMKEEN</span></a>
                <h2><Link to ="/Tadka" className="product-link">PUNJABI TADKA</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price">€23.90</li>
                    <li className="current-price">€21.51</li>
                  </ul>
                </div>
              </div>
            </article>
          </div>
          {/* Single Item */}
          <div className="feature-slider-item">
            <article className="list-product">
              <div className="img-block">
              <Link to ="/Shop" className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/organic/product-2.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/organic/product-15.jpg" alt />
                </Link>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <div className="product-decs">
                <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                <h2><Link to ="/Shop" className="product-link">FRESH FRUIT JUICE</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price">€35.90</li>
                    <li className="current-price">€34.11</li>
                  </ul>
                </div>
              </div>
            </article>
            <article className="list-product">
              <div className="img-block">
              <Link to ="/Shop"className="thumbnail">
                  <img className="first-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                  <img className="second-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                </Link>
                <div className="quick-view">
                  <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                    <i className="ion-ios-search-strong" />
                  </a>
                </div>
              </div>
              <div className="product-decs">
                <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
                <h2><Link to ="/Mangoes" className="product-link">JUICY MANGO</Link></h2>
                <div className="rating-product">
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                  <i className="ion-android-star" />
                </div>
                <div className="pricing-meta">
                  <ul>
                    <li className="old-price">€35.90</li>
                    <li className="current-price">€34.11</li>
                  </ul>
                </div>
              </div>
            </article>
          </div>
          {/* Feature Slider End */}
        </div>
      </div></section>
    {/* Feature Area End */}
    {/* Banner Area 2 Start */}
    <div className="banner-area-2">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            <div className="banner-inner">
            <Link to ="/Shop"><img src="assets/images/banner-image/4.jpg" alt /></Link>
            </div>
          </div>
        </div>
      </div>
    </div>
    {/* Banner Area 2 End */}
    {/* Recent Add Product Area Start */}
    <section className="recent-add-area">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
            {/* Section Title */}
            <div className="section-title">
              <h2>Recently Added</h2>
              <p>ECOLIFE'S RECENTLY ADDED</p>
            </div>
            {/* Section Title */}
          </div>
        </div>
        {/* Recent Product slider Start */}
        <div className="recent-product-slider owl-carousel owl-nav-style">
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
            <Link to ="/Tadka" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-11.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-12.jpg" alt />
              </Link>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>NAMKEEN</span></a>
              <h2><Link to ="/Tadka" className="product-link">PUNJABI TADKA</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€23.90</li>
                  <li className="current-price">€21.51</li>
                  <li className="discount-price">-10%</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
                  <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
            <Link to ="/Mangoes" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-1.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-1.jpg" alt />
              </Link>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
              <h2><Link to ="/Mangoes" className="product-link">JUICY MANGO</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price">€35.90</li>
                  <li className="current-price">€34.21</li>
                  <li className="discount-price">-5%</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
                  <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
            <Link to ="/Almonds" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-3.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-4.jpg" alt />
              </Link>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>NUTS</span></a>
              <h2><Link to ="/Almonds" className="product-link">CALIFORNIA ALMONDS</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€29.90</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
                  <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
            <Link to ="/Strawberry" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-6.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-6.jpg" alt />
              </Link>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>FRESHO</span></a>
              <h2><Link to ="/Strawberry" className="product-link">FRESH STRAWBERRIES</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€29.90</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
 <            Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
          <article className="list-product">
            <div className="img-block">
           < Link to ="/Pomogranade" className="thumbnail">
                <img className="first-img" src="assets/images/product-image/organic/product-22.jpg" alt />
                <img className="second-img" src="assets/images/product-image/organic/product-15.jpg" alt />
              </Link>
              <div className="quick-view">
                <a className="quick_view" href="#" data-link-action="quickview" title="Quick view" data-toggle="modal" data-target="#exampleModal">
                  <i className="ion-ios-search-strong" />
                </a>
              </div>
            </div>
            <ul className="product-flag">
              <li className="new">New</li>
            </ul>
            <div className="product-decs">
              <a className="inner-link" Link to ="/Shop"><span>SAUCE</span></a>
              <h2>< Link to ="/Pomogranade" className="product-link">POMOGRANDE JUICE</Link></h2>
              <div className="rating-product">
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
                <i className="ion-android-star" />
              </div>
              <div className="pricing-meta">
                <ul>
                  <li className="old-price not-cut">€29.90</li>
                </ul>
              </div>
            </div>
            <div className="add-to-link">
              <ul>
                <li className="cart"><Link to ="/Cart" className="cart-btn" >ADD TO CART </Link></li>
                <li>
                  <Link to ="/Wishlist"><i className="ion-android-favorite-outline" /></Link>
                </li>
                <li>
                  <Link to ="/Compare"><i className="ion-ios-shuffle-strong" /></Link>
                </li>
              </ul>
            </div>
          </article>
          {/* Single Item */}
          {/* Recent product slider end */}
        </div>
      </div></section>
    {/* Recent product area end */}
    {/* Brand area start */}
    <div className="brand-area">
      <div className="container">
        <div className="brand-slider owl-carousel owl-nav-style owl-nav-style-2">
          <div className="brand-slider-item">
            <a href="#"><img src="assets/images/brand-logo/1.jpg" alt /></a>
          </div>
          <div className="brand-slider-item">
            <a href="#"><img src="assets/images/brand-logo/2.jpg" alt /></a>
          </div>
          <div className="brand-slider-item">
            <a href="#"><img src="assets/images/brand-logo/3.jpg" alt /></a>
          </div>
          <div className="brand-slider-item">
            <a href="#"><img src="assets/images/brand-logo/4.jpg" alt /></a>
          </div>
          <div className="brand-slider-item">
            <a href="#"><img src="assets/images/brand-logo/5.jpg" alt /></a>
          </div>
          <div className="brand-slider-item">
            <a href="#"><img src="assets/images/brand-logo/1.jpg" alt /></a>
          </div>
          <div className="brand-slider-item">
            <a href="#"><img src="assets/images/brand-logo/2.jpg" alt /></a>
          </div>
        </div>
      </div>
    </div>
    
 
    </div>
     );
  }
}
export default Organic;