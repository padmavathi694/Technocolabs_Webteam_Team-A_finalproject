import React from 'react';
import {Link} from 'react-router-dom';
  class Product2 extends React.Component{
  render(){
  return(
      <div>
<div>
  {/* Breadcrumb Area start */}
  <section className="breadcrumb-area">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <div className="breadcrumb-content">
            <h1 className="breadcrumb-hrading">Blog Post</h1>
            <ul className="breadcrumb-links">
              <li><a href="index.html">Home</a></li>
              <li>Blog Grid Right Sidebar</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* Breadcrumb Area End */}
  {/* Shop Category Area End */}
  <div className="shop-category-area blog-grid">
    <div className="container">
      <div className="row">
        <div className="col-lg-9 col-md-12">
          <div className="blog-posts">
            <div className="row">
              <div className="col-md-6 mb-res-sm-30px">
                <div className="single-blog-post blog-grid-post">
                  <div className="blog-post-media">
                    <div className="blog-image">
                      <a href="#"><img src="assets/images/product-image/medical/9.jpg" alt="blog" /></a>
                    </div>
                  </div>
                  <div className="blog-post-content-inner mt-30">
                    <h4 className="blog-title"><a href="#">Thermometer by vandalay</a></h4>
                    <ul className="blog-page-meta">
                      <li>
                        <a href="#"><i className="ion-person" /> Admin</a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-calendar" /> 24 April, 2020</a>
                      </li>
                    </ul>
                    <p>
                      Regularly checking employees’ body temperature in the workplace is key to controlling the spread of Covid-19. Anyone with a body temperature of more than 37.5ºC could be showing symptoms of the virus, and therefore strict safety precautions must be put in place to protect the other employees.
                      An infrared digital thermometer is an effective ally in the battle against Covid-19 in areas or places with a large number of people, as it allows the body temperature to be reliably and hygienically measured from a distance.It is important to take the following recommendations into account when using the device:
                      Do not place your hands on the thermometer’s sensor, as this could affect the accuracy of the reading.
                      Keep it away from electromagnetic devices such as mobile telephones, smart watches or headsets.
                      Allow the employee to get used to the temperature in the room before taking their body temperature.
                    </p>
                  </div>
                </div>
                {/* single blog post */}
              </div>
              <div className="col-md-6">
                <div className="single-blog-post blog-grid-post">
                  <div className="blog-post-media">
                    <div className="blog-gallery">
                      <div className="gallery-item">
                        <a href="#"><img src="assets/images/product-image/cosmatic/1.jpg" alt="blog" /></a>
                      </div>
                      <div className="gallery-item">
                        <a href="#"><img src="assets/images/blog-image/blog-3.jpg" alt="blog" /></a>
                      </div>
                      <div className="gallery-item">
                        <a href="#"><img src="assets/images/blog-image/blog-4.jpg" alt="blog" /></a>
                      </div>
                    </div>
                  </div>
                  <div className="blog-post-content-inner mt-30">
                    <h4 className="blog-title"><a href="#">Face Concealor</a></h4>
                    <ul className="blog-page-meta">
                      <li>
                        <a href="#"><i className="ion-person" /> Admin</a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-calendar" /> 24 April, 2020</a>
                      </li>
                    </ul>
                    <p>
                      Like foundation, concealer comes in many different formulations to suit every skin type.
                      Liquid concealer - Good for almost every skin type and has coverage ranging from light to full. It's the most versatile of all the options and is easy to apply. This type is our favorite for concealing acne because it's unlikely to cake up (thus drawing more attention to those blemishes). 
                      Stick Concealer - This type of concealer is good for all skin types except oily. It tends to slide off in that case. Coverage is buildable and ranges from medium to full. Our favorite part? It fits perfectly in your purse!
                      Cream Concealer - Cream concealer works for all skin types but very oily. It offers full coverage and is the best if you're trying to cover severe discolorations like birth marks or melasma. Because it's so heavy, you need to be careful to blend really well.Begin with clean skin, then apply a light eye cream followed by a quality primer. Using either your tool of choice (we prefer a concealer brush), draw an upside-down triangle with the base along your bottom lash line, ending in a point at your cheekbone. It looks clownish now, but after blending and adding foundation, it will make your eyes really pop.   
                    </p>
                  </div>
                </div>
                {/* single blog post */}
                {/* single blog post */}
              </div>
              <div className="col-md-6">
                <div className="single-blog-post blog-grid-post mt-30">
                  <div className="blog-post-media">
                    <div className="blog-image">
                      <a href="#"><img src="assets/images/product-image/electronic/1.jpg" alt="blog" /></a>
                    </div>
                  </div>
                  <div className="blog-post-content-inner mt-30">
                    <h4 className="blog-title"><a href="#">CCTV camera</a></h4>
                    <ul className="blog-page-meta">
                      <li>
                        <a href="#"><i className="ion-person" /> Admin</a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-calendar" /> 24 April, 2020</a>
                      </li>
                    </ul>
                    <p>UNV (Uniview) cameras are currently used in a variety of major applications around the globe, thanks in part to the advanced features and easy-to-operate systems. However, it isn’t recommended that you install this type of equipment without the help of an experienced professional like Camera Security Now.
                      To get the most out of your Uniview IPC6222ER-X30P-B PTZ or to order cameras for your facility, contact Camera Security Now today at 800-440-1662 or by logging onto our website and filling out a quick, easy quote request.30X Optical Zoom
                      Accurate and fast focusing
                      Smart IR, up to 150m (492ft) IR distance
                      Optical glass window with higher light transmittance
                      IR anti-reflection window to increase the infrared transmittance
                      120dB true WDR.
                    </p>
                  </div>
                </div>
                {/* single blog post */}
              </div>
              <div className="col-md-6">
                <div className="single-blog-post blog-grid-post mt-30">
                  <div className="blog-post-media">
                    <div className="blog-image">
                      <a href="#"><img src="assets/images/product-image/electronic/13.jpg" alt="blog" /></a>
                    </div>
                  </div>
                  <div className="blog-post-content-inner mt-30">
                    <h4 className="blog-title"><a href="#">Boat speaker</a></h4>
                    <ul className="blog-page-meta">
                      <li>
                        <a href="#"><i className="ion-person" /> Admin</a>
                      </li>
                      <li>
                        <a href="#"><i className="ion-calendar" /> 24 April, 2020</a>
                      </li>
                    </ul>
                    <p>
                      Every penny matters here, worth every buck you pay for this gem. boat stone 1401 is easily one of the best boat bluetooth speaker . There are two reasons to affirm this speaker as one of the best by speaker from boat. Let us see what the reasons are.
                      Sound is produced based on the rapid vibration of diaphragm. Size of the diaphragm in this speaker is about 70mm and that’s exactly 7 cm. It is a universal fact that there is no replacement for displacement. This is why boat STONE 1401 delivers thunderous audio output effortlessly.This speaker is runs on a 2500 mAh lithium battery. Its charging time of 4.5 hour. It was able to last for the entire night. However the playtime is not absolute, depending on the operating volume it may exceed even more than claimed time.
                      So, is size of the diaphragm the sole reason for its thumping performance? No, definitely no. Diaphragm size doesn’t just contribute to decibel level also known as Db. Sound’s clarity is also determined by diaphragm size.  dB output of boat stone 1401 is 75 dB.
                    </p>
                  </div>
                </div>
                {/* single blog post */}
              </div>
            </div>
          </div>
          {/*  Pagination Area Start */}
          {/*  Pagination Area End */}
        </div>
        {/* Sidebar Area Start */}
        <div className="col-lg-3 col-md-12 mb-res-md-60px mb-res-sm-60px">
          <div className="left-sidebar">
            {/* Sidebar single item */}
            <div className="sidebar-widget">
              <div className="main-heading">
                <h2>Search</h2>
              </div>
              <div className="search-widget">
                <form action="#">
                  <input placeholder="Search entire store here ..." type="text" />
                  <button type="submit"><i className="ion-ios-search-strong" /></button>
                </form>
              </div>
            </div>
            {/* Sidebar single item */}
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Categories</h2>
              </div>
              <div className="category-post">
                <ul>
                  <li><a href="#">Dresses (20)</a></li>
                  <li><a href="#">Jackets &amp; Coats (9)</a></li>
                  <li><a href="#">Sweaters (5)</a></li>
                  <li><a href="#">Jeans (11)</a></li>
                  <li><a href="#">Blouses &amp; Shirts (3)</a></li>
                  <li><a href="#">Electronic Cigarettes (6)</a></li>
                  <li><a href="#">Bags &amp; Cases (4)</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Recent Post</h2>
              </div>
              <div className="recent-post-widget">
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-1.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is First Post For XipBlog </a></h5>
                    <span className="date">APRIL 24, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-2.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Secound Post For XipBlog </a></h5>
                    <span className="date">APRIL 25, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side">
                    <a href="#"><img src="assets/images/blog-image/blog-3.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Third Post For XipBlog </a></h5>
                    <span className="date">APRIL 26, 2020</span>
                  </div>
                </div>
                <div className="recent-single-post d-flex">
                  <div className="thumb-side m-0px">
                    <a href="#"><img src="assets/images/blog-image/blog-4.jpg" alt /></a>
                  </div>
                  <div className="media-side">
                    <h5><a href="#">This Is Fourth Post For XipBlog </a></h5>
                    <span className="date">APRIL 27, 2020</span>
                  </div>
                </div>
              </div>
            </div>
            {/* Sidebar single item */}
            <div className="sidebar-widget mt-40">
              <div className="main-heading">
                <h2>Tag</h2>
              </div>
              <div className="sidebar-widget-tag">
                <ul>
                  <li><a href="#">Fresh Fruit</a></li>
                  <li><a href="#"> Fresh Vegetables</a></li>
                  <li><a href="#">Fresh Salad</a></li>
                  <li><a href="#"> Butter &amp; Eggs</a></li>
                </ul>
              </div>
            </div>
            {/* Sidebar single item */}
          </div>
        </div>
        {/* Sidebar Area End */}
      </div>
    </div>
  </div>
  {/* Shop Category Area End */}
</div>

          </div>
  )
  }
}
export default Product2;